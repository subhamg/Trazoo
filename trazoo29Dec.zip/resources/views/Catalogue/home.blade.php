@extends('layouts.userDashboard')

@section('content')
    <div class="col-md-10" style="background-color:transparent;margin-top:50px;">
        <nav class="navbar navbar-default "
             style="  background-color: transparent; border: none;  ">
            <div class="container">
                <div class="Home">
                    Home
                </div>
                <!--<div class="product">(1002 Products)</div>-->
                <!--<div class="sort-by-btn marg-t10 marg-l10" id="filter-btn"
                     style="float: right; margin-right: 20px; margin-left: 90px;"><i class="fa fa-filter"
                                                                                     aria-hidden="true"></i> Filter
                </div>
                <div class="top_search_warp">
                    <input type="text"
                           style="background-color: transparent; border-bottom: 1px solid #d7d7e0; border-radius: inherit; width: 120%;">
                    <span class="search_icon">
                          <button><i class="fa fa-search" aria-hidden="true"></i></button>
                        </span>
                </div>-->


            </div>
        </nav>
        <div class="Rectangle-15" style="border-radius: 6px; background-color: #ffffff;border: solid 1px #e9edf8;">
            <div class="Screen-Shot-2017-12-25-at-33958-PM" ></div>
            <p class="Welcome-Rimpy">Welcome Rimpy,</p>
            <p class="Lets-get-you-started">Lets get you started by adding proucts to Trazoo Inventory.<br>
                Click on the button below to add a prouct.</p>
            <button class="button-primary" style="margin: 24px 484px 0px 484px;">Add Product</button>
        </div>





@endsection