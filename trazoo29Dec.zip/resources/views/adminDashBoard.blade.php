    T@extends('layouts.adminNav')

@section('content')

<div class="adminDashBoard">
                Click On Users to see all users.
</div>


@endsection
