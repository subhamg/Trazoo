<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    //

    protected $table='products';
    protected $fillable = [
        'product_name',
        'product_code',
        'product_photo',
        'product_type1',
        'product_type2',
        'product_type3',
        'product_type4',
        'selling_format',
        'moq',
        'whole_sale_price',
        'mrp',
        'shipping_time',
        'in_stock',
        'description',
        'status',
        'warranty_applicable',
        'warranty_duration_date',
        'warranty_duration_month',
        'warranty_provider',
        'warranty_type',
        'total_variants',
        'brand_name',
        'style_type',
        'ideal_for',
        'fabric',
        'color',
        'size',
        'fit_type',
        'pattern_type',
        'wash_care',
        'shipping_resp',
        'free_shipping',
        'weight_per_unit',
        'item_in_one_box',
        'box_dimension_Length',
        'box_dimension_Breadth',
        'box_dimension_Height',
        'user_id',
    ];
}
