<!Doctype>
<html>
<head>
    <link rel="stylesheet" href="{{ asset('css/trazoo.css') }}">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link href="{{ asset('css/bootstrap.css') }}" rel="stylesheet">
    <link href="{{ asset('css/all.css') }}" rel="stylesheet">

    <script src="{{asset('js/product.js')}}"></script>
    <link rel="stylesheet" href="{{ asset('/css/products.css') }}" type="text/css">

</head>

<body>

<nav class="navbar navbar-default" style="margin-bottom: 16px;">
    <div class="container-fluid"
         style="color:white;background-color: #234bbe;box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.11);">
        <div class="navbar-header">
            <a class="navbar-brand" style="color:white" href="#">Trazoo</a>
        </div>
        <ul class="nav navbar-nav" style="float:right;">
            <li class="active"><input type="text" class="input-field-select" placeholder="Search"></li>
            <li>
                <button class="btn-add-product">Edit Product</button>
            </li>
            <li><a href="#" style="color:white">? Help</a></li>
            <li><a href="#"
                   style="border-radius: 100%;background-color: aqua;width:28px;height:28px;margin: 10px 10px;"></a>
            </li>
        </ul>
    </div>
</nav>


<div class="container-fluid">
    <div class="row">
        <div class="col-lg-7" style="background-color:white">
            <div class="edit-product-box" style="">
                <div class="stepwizard ">
                    <h2>Edit Product</h2>
                    <p style="color:#aaaab4;padding-bottom: 30px;">Home > Add Turtle Blue Solid Formal T-Shirt</p>
                </div>


                <div class="stepwizard ">

                    <div class="stepwizard-row setup-panel">
                        <div class="stepwizard-step">
                            <a href="#step-1" type="button" class="btn btn-primary btn-circle">1</a>
                            Product Details
                        </div>
                        <div class="stepwizard-step">
                            <a href="#step-2" type="button" class="btn btn-default btn-circle" disabled="disabled">2</a>
                            Feature Information
                        </div>
                        <div class="stepwizard-step">
                            <a href="#step-3" type="button" class="btn btn-default btn-circle" disabled="disabled">3</a>
                            Shipping Information
                        </div>
                    </div>
                </div>


                <form role="form" method="POST" action="{{ route('products.update') }}">
                    <input type="hidden" name="_token" value="{{ csrf_token() }}">

                    <div class="row setup-content" id="step-1">
                        <div class="col-xs-12 ">
                            <div class="col-md-12" style="padding-left: 0px;padding-right: 0px;">
                                <div class="form-group " style="padding-top: 40px">
                                    <label for="product_name" class="control-label">Product Name</label>
                                    <input id="product_name" maxlength="100" type="text" required="required"
                                           class="form-control"
                                           name="product_name" placeholder="Enter Product Name"/>
                                </div>
                                <div class="form-group">
                                    <label for="product_photo" class="control-label">Upload Product Image</label>
                                    <input type="file" name="product_photo" id="product_photo">
                                </div>
                                <div class="form-group">
                                    <label class="control-label" style="margin-bottom:0">Product Type</label>
                                    <div>
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <select id="product_type1" name="product_type1" class="product-type">
                                                    <option value="Fashion & Acessories">Fashion & Acessories</option>
                                                    <option value="2">2</option>
                                                    <option value="3">3</option>
                                                    <option value="4">4</option>
                                                </select>
                                            </div>
                                            <div class="col-sm-6">
                                                <select id="product_type2" name="product_type2" class="product-type">
                                                    <option value="Mens Clothing">Mens Clothing</option>
                                                    <option value="2">2</option>
                                                    <option value="3">3</option>
                                                    <option value="4">4</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <select id="product_type3" name="product_type3" class="product-type">
                                                    <option value="Western Wear">Western Wear</option>
                                                    <option value="2">2</option>
                                                    <option value="3">3</option>
                                                    <option value="4">4</option>
                                                </select>
                                            </div>
                                            <div class="col-sm-6">
                                                <select id="product_type4" name="product_type4" class="product-type">
                                                    <option value="Shirts">Shirts</option>
                                                    <option value="2">2</option>
                                                    <option value="3">3</option>
                                                    <option value="4">4</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="form-group">
                                    <label for="selling_format" class="control-label">Selling Format</label>
                                    <br>
                                    <label class="radio-inline"><input type="radio" id="selling_format"
                                                                       name="selling_format" value="Piece">Piece</label>
                                    <label class="radio-inline"><input type="radio" id="selling_format"
                                                                       name="selling_format" value="Lot">Lot</label>
                                    <label class="radio-inline"><input type="radio" id="selling_format"
                                                                       name="selling_format" value="Set">Set</label>
                                </div>
                                <div class="form-group">
                                    <label for="moq" class="control-label" style="margin-bottom:0">Minimum Order
                                        Quantity</label>
                                    <div>
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <select id="moq" name="moq" class="minimum-order-quantity">
                                                    <option value="300">300</option>
                                                    <option value="2">2</option>
                                                    <option value="3">3</option>
                                                    <option value="4">4</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="whole_sale_price" class=" control-label">Wholesale Price</label>
                                    <div class="row">
                                        <div class="col-sm-1" style="padding-right:0;">
                                            <span class="currency">$</span>
                                        </div>
                                        <div class="col-sm-5" style="padding-left: 0">
                                            <input id="whole_sale_price" name="whole_sale_price" type="text"
                                                   placeholder="Amount" class="price">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="mrp" class=<label class="control-label">MRP</label>
                                    <div class="row">
                                        <div class="col-sm-1" style="padding-right:0;">
                                            <span class="currency">$</span>
                                        </div>
                                        <div class="col-sm-5" style="padding-left: 0">
                                            <input id="mrp" name="mrp" type="text" placeholder="Amount" class="price">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="shipping_time" class="control-label" style="margin-bottom:0">Shipping
                                        Time</label>
                                    <div>
                                        <div class="row">
                                            <div class="col-sm-3">
                                                <select id="shipping_time" name="shipping_time"
                                                        class="minimum-order-quantity">
                                                    <option hidden >03</option>
                                                    <option value="2">2</option>
                                                    <option value="3">3</option>
                                                    <option value="4">4</option>
                                                </select>
                                            </div>
                                            <div class="'col-sm-1">
                                                <h5 style="margin-top:17px;font-weight: bold;">Days</h5>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="in_stock" class="control=label">In Stock</label>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <input id="in_stock" name="in_stock" type="text" class="in-stock"
                                                   placeholder="In Stock">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="decription" class="control=label">Product Description</label>
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <input id="decription" name="description" type="text"
                                                   class="product-description"
                                                   placeholder="Describe your product here...">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="status" class="control-label">Status</label>
                                    <br>
                                    <label class="radio-inline"><input type="radio" id="status"
                                                                       name="status" value="Public">Public</label>
                                    <label class="radio-inline"><input type="radio" id="status"
                                                                       name="status" value="Private">Private</label>
                                    <label class="radio-inline"><input type="radio" id="status"
                                                                       name="status" value="Hidden">Hidden</label>
                                </div>
                                <div class="form-group">
                                    <input for="warranty_applicable" name="warranty_applicable" id="warranty_applicable"
                                           type="checkbox">
                                    Warranty Applicable
                                </div>
                                <div class="form-group">
                                    <label for="warranty_duration" class="control-label">Warranty Duration</label>
                                    <div class="row">
                                        <div class="col-sm-2" style="padding-right:0;">
                                            <select id="warranty_duration_date" name="warranty_duration_date"
                                                    class="date">
                                                <option value="08">08</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                            </select>
                                        </div>
                                        <div class="col-sm-4" style="padding-left: 0">
                                            <select id="warranty_duration_month" name="warranty_duration_month"
                                                    class="month">
                                                <option hidden>Months</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="warranty_provider" class="control-label">Warranty Provider</label>
                                    <br>
                                    <label class="radio-inline"><input type="radio" id="warranty_provider"
                                                                       name="warranty_provider" value="Manufacture">Manufacture</label>
                                    <label class="radio-inline"><input type="radio" id="warranty_provider"
                                                                       name="warranty_provider" value="Seller">Seller</label>
                                </div>
                                <div class="form-group">
                                    <label for="warranty_type" class="control-label">Warranty Type</label>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <select id="warranty_type" name="warranty_type" class="warranty-type">
                                                <option hidden>Manufacturing Defect</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>


                                <div class="form-group" style="border-top: solid 1px #d7d7e0;margin:0;">
                                    <br>
                                    <button class="btn btn-primary nextBtn btn-lg pull-right" type="button"
                                            id="button-primary">Next
                                    </button>
                                    <button class="button-secondary">Cancel</button>                 <!--3 Button-->

                                </div>

                            </div>
                        </div>
                    </div>


                    <div class="row setup-content" id="step-2">
                        <div class="col-lg-12 ">


                            <div class="col-md-12" style="padding-left: 0px;padding-right: 0px;">


                                <div class="form-group" style="padding-top: 40px">

                                    <label for="brand_name" class="control-label">Brand Name</label>
                                    <input id="brand_name" name="brand_name" maxlength="200" type="text"
                                           required="required" class="form-control"
                                           placeholder="Enter Company Name"/>
                                </div>


                                <div class="form-group">
                                    <label for="style_type" class="control-label">Style Type</label>
                                    <input id="style_type" name="style_type" maxlength="200" type="text"
                                           required="required" class="form-control"
                                           placeholder="Enter Company Address"/>
                                </div>


                                <div class="form-group">
                                    <label for="ideal_for" class="control-label">Ideal For</label>
                                    <br>
                                    <label class="radio-inline"><input type="radio" id="ideal_for" name="ideal_for" value="Men">Men</label>
                                    <label class="radio-inline"><input type="radio" id="ideal_for" name="ideal_for" value="Women">Women</label>
                                    <label class="radio-inline"><input type="radio" id="ideal_for" name="ideal_for" value="Children">Children</label>

                                </div>


                                <div class="form-group">
                                    <label for="fabric" class="control-label" style="margin-bottom:0">Fabric</label>
                                    <div>
                                        <div class="row">
                                            <div class="col-sm-6 col-md-6">
                                                <select id="fabric" name="fabric" class="form-control">
                                                    <option hidden>Denim</option>
                                                    <option value="2">2</option>
                                                    <option value="3">3</option>
                                                    <option value="4">4</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="form-group">
                                    <label for="color" class="control-label" style="margin-bottom:0">Colour</label>
                                    <div>
                                        <div class="row">
                                            <div class="col-sm-6 col-md-6">
                                                <select id="color" name="color" class="form-control">
                                                    <option hidden>Blue</option>
                                                    <option value="2">2</option>
                                                    <option value="3">3</option>
                                                    <option value="4">4</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="form-group">
                                    <label for="size" class="control-label" style="margin-bottom:0">Size</label>
                                    <div>
                                        <div class="row">
                                            <div class="col-sm-6 col-md-6">
                                                <select id="size" name="size" class="form-control">
                                                    <option value="32">32</option>
                                                    <option value="2">2</option>
                                                    <option value="3">3</option>
                                                    <option value="4">4</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="form-group">
                                    <label for="fit_type" class="control-label" style="margin-bottom:0">Fit Type</label>
                                    <div>
                                        <div class="row">
                                            <div class="col-sm-6 col-md-6">
                                                <select id="fit_type" name="fit_type" class="form-control">
                                                    <option hidden>Boot Cut</option>
                                                    <option value="2">2</option>
                                                    <option value="3">3</option>
                                                    <option value="4">4</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="form-group">
                                    <label for="pattern_type" class="control-label" style="margin-bottom:0">Pattern
                                        Type</label>
                                    <div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <select id="pattern_type" name="pattern_type" class="form-control">
                                                    <option hidden>Faded</option>
                                                    <option value="2">2</option>
                                                    <option value="3">3</option>
                                                    <option value="4">4</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="form-group">
                                    <label for="wash_care" class="control-label" style="margin-bottom:0">Wash
                                        Care</label>
                                    <div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <select id="wash_care" name="wash_care" class="form-control">
                                                    <option hidden>Luke Warm Water</option>
                                                    <option value="2">2</option>
                                                    <option value="3">3</option>
                                                    <option value="4">4</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                            </div>


                            <div class="form-group" style="border-top: solid 1px #d7d7e0;margin:0;">
                                <br>
                                <button class="btn btn-primary nextBtn btn-lg pull-right" type="button"
                                        id="button-primary">Next
                                </button>


                                <button class="button-secondary">Cancel</button>
                                <!--Secondary Button-->

                            </div>

                        </div>
                    </div>


                    <div class="row setup-content" id="step-3">
                        <div class="col-xs-6">


                            <div class="col-md-12" style="padding-left: 0px;padding-right: 0px;">


                                <div class="form-group" style="padding-top: 40px">
                                    <label for="shipping_resp" class="control-label">Shipping Responsibility</label>
                                    <br>
                                    <label class="radio-inline"><input type="radio" id="shipping_resp"
                                                                       name="shipping_resp" value="Trazoo">Trazoo</label>
                                    <label class="radio-inline"><input type="radio" id="shipping_resp"
                                                                       name="shipping_resp" value="Self">Self</label>
                                </div>


                                <div class="form-group">
                                    <label for="free_shipping" class="control-label">Free Shipping</label>
                                    <br>
                                    <label class="radio-inline"><input type="radio" id="free_shipping"
                                                                       name="free_shipping" value="Yes">Yes</label>
                                    <label class="radio-inline"><input type="radio" id="free_shipping"
                                                                       name="free_shipping" value="No">No</label>
                                </div>


                                <div class="form-group">
                                    <label for="weight_per_unit" class="control-label" style="margin-bottom:0">Weight
                                        Per Unit (Kg)</label>
                                    <div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <select id="weight_per_unit" name="weight_per_unit"
                                                        class="form-control">
                                                    <option value="1">1</option>
                                                    <option value="2">2</option>
                                                    <option value="3">3</option>
                                                    <option value="4">4</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="form-group">
                                    <label for="item_in_one_box" class="control-label" style="margin-bottom:0">Items In
                                        one Box</label>
                                    <div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <select id="item_in_one_box" name="item_in_one_box"
                                                        class="form-control">
                                                    <option value="1">1</option>
                                                    <option value="2">2</option>
                                                    <option value="3">3</option>
                                                    <option value="4">4</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="form-group">
                                    <label class="control-label" style="margin-bottom:0">Box Dimensions</label>
                                    <div>
                                        <div class="row">

                                            <div class="col-md-4">
                                                <input id="box_dimension_Length" name="box_dimension_Length"
                                                       maxlength="200" type="text" required="required"
                                                       class="form-control"
                                                       placeholder="Inc"/>
                                            </div>


                                            <div class="col-md-4">
                                                <input id="box_dimension_Breadth" name="box_dimension_Breadth"
                                                       maxlength="200" type="text" required="required"
                                                       class="form-control"
                                                       placeholder="Inc"/>
                                            </div>


                                            <div class="col-md-4">
                                                <input id="box_dimension_Height" name="box_dimension_Height"
                                                       maxlength="200" type="text" required="required"
                                                       class="form-control"
                                                       placeholder="Inc"/>
                                            </div>


                                        </div>
                                    </div>
                                </div>


                                <div class="form-group" style="border-top: solid 1px #d7d7e0;margin:0;">
                                    <br>
                                    <button class="btn btn-primary nextBtn btn-lg pull-right" type="submit"
                                            id="button-primary">
                                        Next
                                    </button>
                                    <button class="button-secondary">Cancel</button>                 <!--3 Button-->

                                </div>
                            </div>


                        </div>
                    </div>


                </form>


            </div>
            <div class="col-lg-4" style="background-color: pink"></div>
        </div>
    </div>
</div>
</body>
</html>