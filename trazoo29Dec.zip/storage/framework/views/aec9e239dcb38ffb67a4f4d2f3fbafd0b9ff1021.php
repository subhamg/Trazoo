<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    
    <title>Trazoo</title>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/all.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/responsive.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/filter.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/prettify.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/nprogress.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


    <style>
        body {
            background-color: #f7f9fa;
        }

        .main_menu_side {
            padding-top: 50px;

            font-family: OpenSans;
            font-size: 12px;
            font-weight: normal;
            font-style: normal;
            font-stretch: normal;
            line-height: normal;
            letter-spacing: normal;

        }

        .nav.side-menu > li > a {
            color: #0a0a14;
            margin-bottom: 0px;
        }

        .menu_section > ul {
            margin-top: 0px;
        }

        .glyphicon {
            padding-right: 5px;
        }

        .main_menu .fa {
            width: 20px;
            font-size: 14px;
        }

        .container > ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
        }

        .container > ul > li {
            float: right;
        }

        .container > ul > li a {
            display: block;
            color: white;
            text-align: center;

            padding-top: 14px;
            padding-right: 24px;
            padding-bottom: 14px;
            text-decoration: none;
            font-size: 13px;
            font-weight: 500;
            text-overflow: ellipsis;
            line-height: 27.5px;
        }

        .search {
            display: block;
            color: white;
            text-align: center;

            margin-top: 14px;
            margin-right: 24px;
            margin-bottom: 14px;
            text-decoration: none;
            font-size: 13px;
            font-weight: 500;
            text-overflow: ellipsis;
            line-height: 25.5px;
            border-radius: 4px;

        }

        input[type=text] {
            border: 0px solid rgba(10, 10, 20, 0.2);
            height: 31px;

        }

        .search button {
            border: 0px solid rgba(10, 10, 20, 0.2);
            height: 31px;
            margin-right: 2px;
        }

        .searchTerm, .searchButton {
            background-color: rgba(10, 10, 20, 0.2);
            border: none;

            box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.11);
        }

        .site_title {
            text-overflow: ellipsis;
            overflow: hidden;
            font-weight: 600;
            font-size: 13px;
            width: 100%;
            color: #fff !important;
            margin-left: 0 !important;
            line-height: 27.5px;
            display: block;
            height: 55px;
            margin: 0;
            padding-left: 24px;

        }

        .glyphicon {
            top: 0px;
        }

        input[type="text"]::-webkit-input-placeholder {
            color: rgba(255, 255, 255, .5);

        }

        .nav .side-menu {
            width: 150px;
        }

        .card {
            width: 244px;
            max-height: 300px;
            border-radius: 6px;
            background-color: #ffffff;
            border: solid 1px #e9edf8;
            display: inline;
            float: left;
            margin-right: 32px;
            margin-bottom: 32px;
        }

        .card img {
            width: 100%;
            padding-left: 6px;
            padding-right: 6px

        }

        .card-image {
            width: 244px;
            height: 172px;
            overflow: hidden;
        }

        .card-img-top {
            width: 100%;
        }

        .card-body {
            width: 100%;
            height: 128px;
        }

        .card-content {
            width: 100%;
            height: 84px;
        }

        .card-setting {
            width: 100%;
            height: 44px;
            padding-top: 10px;
        }

        .card-title {
            width: 288px;
            height: 11px;
            font-family: OpenSans;
            font-size: 13px;
            font-weight: 600;
            font-style: normal;
            font-stretch: normal;
            line-height: 0.85;
            letter-spacing: normal;
            text-align: left;
            color: #0a0a14;
            padding: 12px;

        }

        .layer {
            width: 49px;
            height: 11px;
            font-family: OpenSans;
            font-size: 12px;
            font-weight: normal;
            font-style: normal;
            font-stretch: normal;
            line-height: 0.92;
            letter-spacing: normal;
            text-align: left;
            color: #73737d;
            padding-left: 12px;
        }

        .card .price {
            width: 24px;
            height: 19px;
            font-family: OpenSans;
            font-size: 14px;
            font-weight: 600;
            font-style: normal;
            font-stretch: normal;
            line-height: normal;
            letter-spacing: normal;
            text-align: left;
            color: #000000;
            padding-left: 12px;
            display: inline;
            padding-bottom: 12px;
        }

        .margin {
            width: 76px;
            height: 17px;
            font-family: OpenSans;
            font-size: 12px;
            font-weight: 600;
            font-style: normal;
            font-stretch: normal;
            line-height: normal;
            letter-spacing: normal;
            text-align: left;
            color: #55be4b;
            display: inline;
            padding-left: 6px;
            padding-bottom: 13px;
        }

        .MOQ-Peices {
            width: 180px;
            height: 15px;
            font-family: OpenSans;
            font-size: 11px;
            font-weight: normal;
            font-style: normal;
            font-stretch: normal;
            line-height: normal;
            letter-spacing: normal;
            text-align: left;
            color: #000000;
            padding-left: 12px;
            padding-bottom: 18px;
            display: inline;
        }

        hr {
            margin-top: 13px;
            margin-bottom: 0;
        }

        .catalogue-title {
            width: 85px;
            height: 24px;
            font-family: OpenSans;
            font-size: 18px;
            font-weight: normal;
            font-style: normal;
            font-stretch: normal;
            line-height: normal;
            letter-spacing: normal;
            text-align: left;
            color: #0a0a14;
            display: inline;
            float: left;
            padding-top: 18px;
        }

        .product {
            width: 150px;
            height: 17px;
            font-family: OpenSans;
            font-size: 12px;
            font-weight: normal;
            font-style: normal;
            font-stretch: normal;
            line-height: normal;
            letter-spacing: normal;
            text-align: left;
            color: #73737d;
            display: inline;
            float: left;
            padding-top: 23px;
            padding-left: 15px;

        }

        .working .glyphicon-th-large {
            color: #2350f5;

        }

        .working {
            color: #2350f5;
            border-left: 2px solid #2350f5;

        }

        .icon-button{
            width: 28px;
            height: 28px;
            border-radius: 3px;
            background-color: rgba(255, 255, 255, 0.05);
            border: none;
            font-size:18px;
            color: #aaaab4;

        }
        .icon-button:hover{
            color:#73737d;
            border: solid 1px #d7d7e1;
        }
        .icon-button:active{

            background-color: rgba(255, 255, 255,0);
            color: #2350f5;
            border: solid 1px #2350f5;
        }
        .icon-button:disabled{
            background-color: rgba(255, 255, 255, 0.05);
            color: #d7d7e1;
            border: none;
        }


        .icon-button:focus {
            background-color: rgba(255, 255, 255,0);
            color: #2350f5;
            border: solid 1px #2350f5;
            outline:0;}
        .inventory{
            border-radius: 6px;
            background-color: #ffffff;
            border: solid 1px #e9edf8;
            padding: 0px 20px;

        }
        .inventory table{
            width:100%;
            table-layout: fixed;
        }
        table.header{

            margin: 16px 0px 0px 0px;
        }


        #table-scroll {
            
            overflow:auto;
        }

        th {
            border-right: solid 2px #e6e6ed;;
            padding-left: 12px;
            height: 11px;
            font-family: 'Open Sans';
            font-size: 12px;
            font-weight: 600;
            font-style: normal;
            font-stretch: normal;
            line-height: 0.92;
            letter-spacing: normal;
            text-align: left;
            color: #0a0a14;
            border-top:none;
        }
        td{
            font-family: 'Open Sans';
            font-size: 12px;
            font-weight: normal;
            font-style: normal;
            font-stretch: normal;
            line-height: 1;
            letter-spacing: normal;
            text-align: left;
            color: #0a0a14;
            padding-left: 12px;
            height:44px;
        }
        .status-button{
            width: 72px;
            height: 28px;
            font-family: 'Open Sans';
            font-size: 12px;
            font-weight: normal;
            font-style: normal;
            font-stretch: normal;
            line-height: 1;
            letter-spacing: normal;
            text-align: left;
            color: #0a0a14;
            background-color:#ffffff;
            border:none;
        }
        .status-button:hover {
            border-radius: 4px;
            border: solid 1px #d7d7e1;
            background-color:#f6f8fd;

        }
        .drop-img:hover{
            opacity:1;
        }
        .status-button:focus{
            outline:0;
            border-radius: 4px;
            border: solid 1px #d7d7e1;
            opacity:1;
        }
        .status-button:active{
            border-radius: 4px;
            border: solid 1px #d7d7e1;
        }
        input[type=checkbox] {
            opacity: 0;
        }
        .cbox{
            width: 14px;
            height: 14px;

            position:relative;
        }
        .cbox label {
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
        .cbox label:before {
            content: '';
            top: 0;
            left: 0;
            width: 14px;
            height: 14px;
            display: block;
            position: absolute;
            border-radius: 2px;
            background-color: #ffffff;
            border: solid 1px #aaaab4;
        }
        .cbox input[type="checkbox"]:checked + label:before {
            border-color: #2350f5;;
            background-color: #2350f5;;
        }
        .cbox input[type="checkbox"]:checked + label:after {
            content: '';
            position: absolute;
            width: 7px;
            height: 3px;
            background: transparent;
            top: 4.1px;
            left: 3.7px;
            border: 2px solid #ffffff;;
            border-top: none;
            border-right: none;
            -webkit-transform: rotate(-45deg);
            -moz-transform: rotate(-45deg);
            -o-transform: rotate(-45deg);
            -ms-transform: rotate(-45deg);
            transform: rotate(-45deg);
        }
        .cbox-header{
            width: 14px;
            height: 14px;

            position:relative;
        }
        .cbox-header label {
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
        .cbox-header label:before {
            content: '';
            top: 0;
            left: 0;
            width: 14px;
            height: 14px;
            display: block;
            position: absolute;
            border-radius: 2px;
            background-color: #ffffff;
            border: solid 1px #aaaab4;
        }
        .cbox-header input[type="checkbox"]:checked + label:before {
            border-color: #2350f5;;
            background-color: #2350f5;;
        }
        .cbox-header input[type="checkbox"]:checked + label:after {
            content: '';
            position: absolute;
            width: 7px;
            height: 3px;
            background: transparent;
            top: 4.1px;
            left: 3.7px;
            border: 2px solid #ffffff;;
            border-top: none;
            border-right: none;
            -webkit-transform: rotate(-45deg);
            -moz-transform: rotate(-45deg);
            -o-transform: rotate(-45deg);
            -ms-transform: rotate(-45deg);
            transform: rotate(-45deg);
        }
        .drop-img{
            padding-left:3px;text-align: right;width: 7.9px;height: 4.4px;color: #aaaab4;padding-bottom: 2px;
            display:none;
        }
        .table-items:hover status-button:hover{
            cursor: pointer;
            background-color: #f6f8fd;
        }


        .table-items-selected {
            border-top: 1px solid #e9edf8;
            border-bottom: 1px solid #e9edf8;
            background-color: #f6f8fd;
        }
        .status-button:disabled{
            border:none;
            background-color:#f6f8fd;
        }




    </style>
</head>

<body class="nav-md">
<nav class="navbar navbar-default navbar-fixed-top"
     style="background-color: #234bbe; box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.11);">
    <div class="container">
        <!-- <a class="navbar-brand" href="#">Trazoo</a>-->
        <ul>
            <li style="float:left"><a href="index.html" class="site_title">Trazoo </a></li>


            <li class="">
                <a href="javascript:;" class="user-profile " aria-expanded="false">
                    <img src="<?php echo e(asset('images/img.jpg')); ?>" alt="">
                </a>

            </li>
            <li><a href=""><i class="fa fa-question-circle-o"></i> Help</a></li>
            <li><a href="">
                    <button type="button" class="btn btn-primary btn-sm"
                            style="background-color:#234bbe; border: 1px solid #fff;">Add Product
                    </button>
                </a></li>
            <li><span class="search"><span class="inner-addon left-addon">
    <span class="glyphicon glyphicon-search"
          style="background-color:rgba(10, 10, 20, 0.2);  height: 31px; padding-left:5px;padding-bottom: 7.5px; padding-top: 7.5px; margin-right:-3px;"></span>
    <input type="text" placeholder="Search People" style="background-color:rgba(10, 10, 20, 0.2);"/>
</span>

            </li>


        </ul>


    </div>
</nav>


<div class="container-fluid" style="padding-left: 0px; paadding-right:0px;">
    <div class="row">
        <div class="col-md-2" style="background-color: #f7f9fa;">
            <div class="left_col scroll-view" style="background-color: #f7f9fa;">


                <div class="clearfix"></div>

                <!-- /menu profile quick info -->

                <br>

                <!-- sidebar menu -->
                <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
                    <div class="menu_section">
                        <ul class="nav side-menu">
                            <li><a href=""><span class="glyphicon glyphicon-home"></span> Home </a></li>
                            <li><a href=""><span class="glyphicon glyphicon-list-alt"></span> Inventory</a></li>
                            <li><a href=""> <i class="fa fa-rupee"></i>Sales </a></li>
                            <li><a href="<?php echo e(route('getAllUsers')); ?>"><span class="glyphicon glyphicon-list"></span>
                                    Orders</a></li>
                            <li class="working"><a href="" style="color: #2350f5;"><span
                                            class="glyphicon glyphicon-th-large"></span> Catalogue </a></li>
                            <li><a href=""> <i class="fa fa-share-alt"></i>Connections </a></li>
                            <li><a href=""><i class="fa fa-ticket"></i>Coupons </a></li>
                            <li><a href=""><i class="fa fa-pencil-square-o"></i>Queries </a></li>

                        </ul>
                    </div>

                </div>
                <!-- /sidebar menu -->

                <!-- /menu footer buttons -->
            </div>
        </div>

        <div class="col-md-10" style="background-color:transparent;margin-top:50px;">
            <nav class="navbar navbar-default "
                 style=" margin-top: 10px; background-color: transparent; border: none;  ">
                <div class="container">
                    <div class="catalogue-title">
                        Catalogue
                    </div>
                    <div class="product">(1002 Products)</div>
                    <div class="sort-by-btn marg-t10 marg-l10" id="filter-btn"
                         style="float: right; margin-right: 20px; margin-left: 90px;"><i class="fa fa-filter"
                                                                                         aria-hidden="true"></i> Filter
                    </div>
                    <div class="top_search_warp">
                        <input type="text"
                               style="background-color: transparent; border-bottom: 1px solid #d7d7e0; border-radius: inherit; width: 120%;">
                        <span class="search_icon">
                              <button><i class="fa fa-search" aria-hidden="true"></i></button>
                            </span>
                    </div>


                </div>
            </nav>

                            <div class="inventory">
                                <table class=" header" style="text-align:left; border-top: 0px; border-bottom:1px solid #d7d7e1">
                        <colgroup>
                        <col span="1" style="width:4.8%;">
                            <col span="1" style="width:8.4%;">
                            <col span="1" style="width:12.6%;">
                            <col span="1" style="width:18.8%;">
                            <col span="1" style="width:9.5%;">
                            <col span="1" style="width:12.8%;">
                            <col span="1" style="width:14%;">
                            <col span="1" style="width:19.7%;">
                        </colgroup>

                        <tbody >
                        <th ><div class="cbox-header">
                                <input type="checkbox"  id="cboxinput-header" onclick="myfunction1()" />
                                <label for="cboxinput-header"></label>
                            </div>
                        </th>
                        <th >Sr No.</th>
                        <th >Product Code</th>
                        <th >Product Name</th>
                        <th >In Stock</th>
                        <th >Total Varients</th>
                        <th>Wholesale Price</th>
                        <th >Status</th>
                        </tbody>
                    </table>
                    <div id="table-scroll">
                        <table   width="100%" id="item-detail">
                            <colgroup>
                                <col span="1" style="width:4.8%;">
                                <col span="1" style="width:8.4%;">
                                <col span="1" style="width:12.6%;">
                                <col span="1" style="width:18.8%">
                                <col span="1" style="width:9.5%">
                                <col span="1" style="width:12.8%">
                                <col span="1" style="width:14%">
                                <col span="1" style="width:15.0%">
                                <col span="1" style="width:4.7%">
                            </colgroup>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody class="items-details">
                            <tr >
                                <td>
                                    <div class="cbox">
                                        <input type="checkbox" id="cboxinput_<?php echo e($p->id); ?>" onclick="myfunction()">
                                        <label for="cboxinput"></label>
                                    </div>
                                </td>
                                <td><?php echo e($p->id); ?></td>
                                <td><?php echo e($p->product_code); ?></td>
                                <td><?php echo e($p->product_name); ?></td>
                                <td><?php echo e($p->in_stock); ?></td>
                                <td><?php echo e($p->total_variants); ?></td>
                                <td><?php echo e($p->whole_sale_price); ?></td>
                                <td><button class="status-button" id="stat-button"><?php echo e($p->status); ?> <span ><img class="drop-img" style="" src="img_237632.png"></span></button></td>
                                <td><button  class="icon-button" id="ic-button" >&#8942</button></td>
                            </tr>
                            </tbody>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>




        </div>
        </div>


        <?php echo $__env->yieldContent('content'); ?>
    </div>


    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

    <script src="<?php echo e(asset('js/fastclick.js')); ?>"></script>
    <script src="<?php echo e(asset('js/nprogress.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap-wysiwyg.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.hotkeys.js')); ?>"></script>
    <script src="<?php echo e(asset('js/prettify.js')); ?>"></script>
<script>
    function myfunction() {
        var items = document.getElementById("item-detail");
        items.classList.toggle("table-items-selected");
        var btn = document.getElementById("stat-button");
        var btn1 = document.getElementById("ic-button");
        var header= document.getElementById("cboxinput-header")
        var row = document.getElementById("cboxinput")
        if(row.checked==false)
        {
            header.checked= false;
            btn.disabled=false;
            btn1.disabled=false;
        }
        if(row.checked==true) {
            btn.disabled = true;
            btn1.disabled=true;
        }



    }
    function myfunction1(){
        var btn1 = document.getElementById("ic-button");
        var btn = document.getElementById("stat-button");
        var items = document.getElementById("item-detail");
        var header= document.getElementById("cboxinput-header");
        var row = document.getElementById("cboxinput");
        if(header.type == "checkbox") {
            if (header.checked == true) {
                row.checked = true;
                items.classList.remove ("table-items");
                items.classList.add ("table-items-selected");
                btn.disabled = true;
                btn1.disabled = true;
            }
            if (header.checked == false) {
                row.checked = false;
                items.classList.remove ("table-items-selected");
                items.classList.add ("table-items");
                btn.disabled = false;
                btn1.disabled = false;
            }
        }




    }

</script>
<?php echo $__env->yieldContent('script'); ?>

<!-- Scripts -->


</body>
</html>
