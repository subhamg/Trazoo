<?php

namespace App\Http\Controllers;

use App\OTP;
use App\User;
use App\Business;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\View;
use Illuminate\Console\Scheduling\Schedule;
use Ixudra\Curl\Facades\Curl;
class AdminController extends Controller
{
    //
    public function getAllUsers(Request $request){


//        $user = USER::where('role',"user")->get();
//        $user = USER::with('Business')->where('role',"user")->get();

        $user = DB::table('users')
            ->join('businesses', 'users.id', '=', 'businesses.user_id')
            ->select('users.*',
                'businesses.businessname',
                'businesses.businesstype',
                'businesses.industry',
                'businesses.addressline1',
                'businesses.addressline2',
                'businesses.landmark',
                'businesses.city',
                'businesses.pincode',
                'businesses.state',
                'businesses.bank',
                'businesses.accountholdername',
                'businesses.accountnumber',
                'businesses.ifsccode',
                'businesses.pannumber',
                'businesses.gstcompliance',
                'businesses.gstin',
                'businesses.vat')
            ->where('users.role','user')
            ->where('users.isBlocked',false)
            ->get();

//        $user =     DB::table('users')
//            ->join('businesses', 'users.id', '=', 'businesses.user_id')
//            ->select(
//                'businesses.businessname',
//                'businesses.businesstype',
//                'businesses.industry',
//                'businesses.addressline1',
//                'businesses.addressline2',
//                'businesses.landmark',
//                'businesses.city',
//                'businesses.pincode',
//                'businesses.state',
//                'businesses.bank',
//                'businesses.accountholdername',
//                'businesses.accountnumber',
//                'businesses.ifsccode',
//                'businesses.pannumber',
//                'businesses.gstcompliance',
//                'businesses.gstin',
//                'businesses.vat',
//                'users.firstname',
//                'users.lastname',
//                'users.email',
//                'users.number'
//
//            )->get();
        error_log('Users are ------------>: ');
        error_log('Users are ------------>: ');
        error_log('Users are ------------>: ');
        if(count($user)>0){
            return view('Admin.userList')->with(array(
                'user'=>$user));
        }
    }

    public function approveUser(Request $request){

        $rules = array(
            'id' => 'required'
        );

        $validator = Validator::make(Input::all(),$rules);
        if($validator -> fails()){
            return Response::json(array('errors' => $validator->getMessageBag()->toArray()));
        }
        else{
                        $user_id = $request->id;

            error_log('--------------------------------------- ');
            error_log('User to be approved is : '+$user_id[0]);
            error_log('--------------------------------------- ');

            \DB::table('users')->whereIn('id',$user_id)->update(['isApproved' => true]);

         return 1;
        }
    }


//            $user_id = $request->id;
//        error_log('--------------------------------------- ');
//        error_log('User to be approved is : '+$user_id);
//        error_log('--------------------------------------- ');
//
//        $user = User::findorfail($user_id);
//        $user->isApproved = true;
//        $user->save();
    public function blockUnbockUser(Request $request){

        $rules = array(
            'id' => 'required'
        );

        $validator = Validator::make(Input::all(),$rules);
        if($validator -> fails()){
            return Response::json(array('errors' => $validator->getMessageBag()->toArray()));
        }
        else{
            $user_id = $request->id;


            error_log('--------------------------------------- ');
            error_log('User to be approved is : '+$user_id[0]);
            error_log('--------------------------------------- ');

            \DB::table('users')->whereIn('id',$user_id)->update(['isBlocked' => true]);


            return 1;
        }
    }

    public function sendOTP(Request $request){

        $rules = array(
            'number' => 'required'
        );

        $validator = Validator::make(Input::all(),$rules);
        if($validator -> fails()){
            return Response::json(array('errors' => $validator->getMessageBag()->toArray()));
        }
        else{
            $user = USER::where('number',$request->number)->first();

            if(count($user)>0) {
       return 0;
            }

            else{
            $phoneNumber = $request->number;
            $otp = rand(1111, 9999);

            $new_user = new OTP();
            $new_user->otp = $otp;
            $new_user->mobile_number = $phoneNumber;
            $new_user->type = "r";
            $new_user->save();

            $otp_message = "Please enter this OTP '".$otp."' for registration";

            $link = "http://tsms.my-reminders.in/api/sendmsg.php?user=trazoo&pass=trazoo@softo2018&
            sender=TRAZOO&phone=".$phoneNumber."&text=".$otp."&priority=dnd&stype=normal";
//            Curl::to('http://tsms.my-reminders.in/api/sendmsg.php?user=trazoo&pass=trazoo@softo2018&sender=TRAZOO&phone='.$phoneNumber.'&text=Please enter this OTP '.$otp.'for creating an account on trazoo&priority=ndnd&stype=normal')
//                ->get();

            Curl::to('http://tsms.my-reminders.in/api/sendmsg.php?user=trazoo&pass=trazoo@softo2018&sender=TRAZOO&phone='.$phoneNumber.'&text='.$otp.'Please+enter+the+otp&priority=ndnd&stype=normal')
                ->get();


            error_log('--------------------------------------- ');

            error_log('--------------------------------------- ');
            error_log('Phone Number is : '+$phoneNumber);
            error_log('$otp is : '+$otp);
            error_log('$link is : '.$link);
            error_log('$otp_message is : '.$otp_message);
            error_log('--------------------------------------- ');

            return 1;
        }
        }
    }


    public function sendOTPResetPassword(Request $request){

        $rules = array(
            'number' => 'required'
        );

        $validator = Validator::make(Input::all(),$rules);
        if($validator -> fails()){
            return Response::json(array('errors' => $validator->getMessageBag()->toArray()));
        }
        else{
            $user = USER::where('number',$request->number)->first();

            if(count($user)>0) {
                $phoneNumber = $request->number;
                $otp = rand(1111, 9999);

                $new_user = new OTP();
                $new_user->otp = $otp;
                $new_user->mobile_number = $phoneNumber;
                $new_user->type = "pr";
                $new_user->save();


//            Curl::to('http://tsms.my-reminders.in/api/sendmsg.php?user=trazoo&pass=trazoo@softo2018&sender=TRAZOO&phone='.$phoneNumber.'&text=Please enter this OTP '.$otp.'for creating an account on trazoo&priority=ndnd&stype=normal')
//                ->get();

                Curl::to('http://tsms.my-reminders.in/api/sendmsg.php?user=trazoo&pass=trazoo@softo2018&sender=TRAZOO&phone='.$phoneNumber.'&text='.$otp.'Please+enter+the+otp&priority=ndnd&stype=normal')
                    ->get();

                error_log('--------------------------------------- ');
                error_log('Phone Number is : '+$phoneNumber);
                error_log('$otp is : '+$otp);
                error_log('--------------------------------------- ');

                return 1;
            }

            else{
                return 0;
            }
        }
    }
}
