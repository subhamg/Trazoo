<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="forget-password col-md-offset-4">


                <?php if(session('status')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>

                <form class="form-horizontal" method="POST" action="<?php echo e(route('password.email')); ?>">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <p id="sendOTPButton" class="Forgot-your-password">Forget your password?</p>
                    <p id="afterSendingOTP" class="Forgot-your-password" style="display: none;">Enter Security Code</p>
                    <p id="afterConfirmingOTP" class="Forgot-your-password" style="display: none;">Choose a new
                        Password</p>

                    <p id="sendOTPButton1" class="No-worries-Lets-fin">No worries, Lets find your account</p>
                    <p id="afterSendingOTP1" class="No-worries-Lets-fin" style="display: none;">We've sent a code to
                        your phone. Once you recieve the code,enter it below to reset your password.</p>
                    <p id="afterConfirmingOTP1" class="No-worries-Lets-fin" style="display: none;">A strong password includes numbers, letters and punctuation marks. It must be  atleast 6 characters long.</p>


                    <div id="sendOTPButton2" id="phoneNumber"
                         class="form-group<?php echo e($errors->has('number') ? ' has-error' : ''); ?>">
                        <label for="email" class="col-md-6 col-md-offset-1 control-label  Enter-your-registere">Enter
                            your phone number</label>
                        <br>

                        <div class=" input_rectangle">
                            <input id="number" type="number" class="form-control" name="number"
                                   value="<?php echo e(old('number')); ?>">
                            <div id="numberLengthError" style="font-size: small;color: red"></div>
                            <?php if($errors->has('number')): ?>
                                <span class="help-block">
                                        <strong><?php echo e($errors->first('number')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div id="afterSendingOTP2" style="display: none">
                        <div class="form-group<?php echo e($errors->has('otp') ? ' has-error' : ''); ?>">
                            <label for="email" class="col-md-5 col-md-offset-0  control-label Enter-your-registere">Enter
                                4 digit Code</label>

                            <div class="input_rectangle">
                                <input id="otp" type="number" maxlength="4" class="form-control" name="otp"
                                       value="<?php echo e(old('otp')); ?>">
                                <div id="otpError" style="font-size: small;color: red"></div>
                                <?php if($errors->has('otp')): ?>

                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('otp')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group" id="afterSendingOTP4">
                            <div class="col-md-6 col-md-offset-7">
                                <button type="button" class="button-primary " onclick="sendEnteredOTP()">
                                    Submit
                                </button>
                            </div>
                        </div>
                    </div>

                    <div id="afterConfirmingOTP2" style="display: none">
                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label for="password" class="col-md-4 control-label">Password</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password" required>
                                <div id="passwordError" style="font-size: small;color: red"></div>

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                            <label for="password-confirm" class="col-md-4 control-label">Confirm Password</label>
                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control"
                                       name="password_confirmation" required>
                                <div id="password-confirmError" style="font-size: small;color: red"></div>

                                <?php if($errors->has('password_confirmation')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group" id="afterConfirmingOTP3">
                            <div class="col-md-6 col-md-offset-7">
                                <button type="button" onclick="changePassword()" class="button-primary ">
                                    Change Password
                                </button>
                            </div>
                        </div>
                    </div>

                    <div id="afterPasswordChanged" style="display: none; text-align: center;">
<div class="full-circle">
                            &#10004;
                            </div>
                        <h3> Congratulations!</h3>

                        <p>Password Changed Successfully.</p> <p>Go back to Login Page.</p>
                    </div>


                    <div class="form-group" id="sendOTPButton4">
                        <div class="col-md-6 col-md-offset-7">
                            <button type="button" class="button-primary " onclick="sendOTP()">
                                Send OTP
                            </button>
                        </div>
                    </div>
                </form>
            </div>

        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>

        var phone;
        var otpSent;
        var otpConfirmed;

        function sendOTP() {
            var phone = document.getElementById('number').value;
            this.phone = phone;
            console.log("this.phone : " + this.phone);

            var phoneLength = document.getElementById('numberLengthError');
            phoneLength.innerHTML = "";
            console.log("phone : " + phone);
            if (phone.length != 10) {
                phoneLength.innerHTML = "Phone number must be of atleast 10 digits.";
                phoneLength.style.color = "red"
            }
            else {
                $.post('/sendOTPResetPassword', {
                    'number': phone,
                    '_token': $('input[name=_token]').val()
                }, function (data) {
                    if (data == 1) {
                        alert("Please enter the OTP sent to your mobile.");
                        $('#sendOTPButton').remove();
                        $('#afterSendingOTP').show();
                        $('#sendOTPButton1').remove();
                        $('#afterSendingOTP1').show();
                        $('#sendOTPButton2').remove();
                        $('#afterSendingOTP2').show();
                        $('#sendOTPButton4').remove();
                        $('#afterSendingOTP4').show();


                        this.otpSent = true;
                    }
                    else if (data == 0) {
                        alert("Account already exists with this mobile number.Please use other number.");
                    }
                    else {
                        alert("Error Sending OTP. Please click on send OTP again..");
                    }
                });
            }

        }


        function sendEnteredOTP() {
            var otp = document.getElementById('otp').value;
            var otpLength = document.getElementById('otpError');
            otpLength.innerHTML = "";
            console.log("phone : " + otpLength);
            if (otp.length < 4) {
                otpLength.innerHTML = "OTP should be of 4 digits.";
                otpLength.style.color = "red"
            }
            else {
                $.post('/resetPasswordUsingOTP', {
                    'number': this.phone,
                    'otp': otp,
                    '_token': $('input[name=_token]').val()
                }, function (data) {
                    if (data == 1) {
                        $('#afterSendingOTP').remove();
                        $('#afterConfirmingOTP').show();
                        $('#afterSendingOTP1').remove();
                        $('#afterConfirmingOTP1').show();
                        $('#afterSendingOTP2').remove();
                        $('#afterConfirmingOTP2').show();
                        $('#afterSendingOTP4').remove();
                        $('#afterConfirmingOTP4').show();

                        this.otpConfirmed = true;
                    }
                    else {
                        alert("Error Sending OTP. Please click on send OTP again..");
                    }
                });
            }

        }

        function changePassword() {
            var password_confirm = document.getElementById('password-confirm').value;
            var password = document.getElementById('password').value;
            var password_Error = document.getElementById('passwordError');
            var password_confirmError = document.getElementById('password-confirmError');
            password_Error.innerHTML = ""
            password_confirmError.innerHTML = ""
            password = password.trim();
            password_confirm = password_confirm.trim();

            if (password.length < 6) {
                password_Error.innerHTML = "Password should be of 6 characters.";
                password_Error.style.color = "red"
            }
            else {
                if (password_confirm == password) {
                    $.post('/changePassword', {
                        'number': this.phone,
                        'password': password,
                        '_token': $('input[name=_token]').val()
                    }, function (data) {
                        if (data == 1) {
                            $('#afterConfirmingOTP').remove();
                            $('#phoneNumber').remove();

                            $('#afterConfirmingOTP').remove();
                            $('#afterConfirmingOTP1').remove();
                            $('#afterConfirmingOTP2').remove();
                            $('#afterConfirmingOTP4').remove();

                            $('#afterPasswordChanged').show();
//                this.otpConfirmed = true;
                            alert("Password Changed..");
                        }
                        else {
                            alert("Password not Changed..");
                        }
                    });
                }
                else {
                    password_Error.innerHTML = "Passwords Do not match.";
                    password_Error.style.color = "red"
                    password_confirmError.innerHTML = "Passwords Do not match.";
                    password_confirmError.style.color = "red"

                }
            }

        }

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>