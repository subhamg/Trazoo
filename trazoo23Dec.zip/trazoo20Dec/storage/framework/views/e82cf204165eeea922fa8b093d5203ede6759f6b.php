<?php $__env->startSection('content'); ?>
    <div class="backgroundColor">
        <div class="divPosition">
            <div class="loginPanelHeading">
                TRAZOO
            </div>

            <form class="form-horizontal" method="POST" action="<?php echo e(route('user.login')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="col-md-10 col-md-offset-1">
                    <?php if(session('message')): ?>
                        <div class="alert alert-warning">
                            <?php echo e(session('message')); ?>

                        </div>
                    <?php endif; ?>
                </div>

                <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                    

                    <div class="col-md-8 col-md-offset-2">
                        <input id="email" type="email" class="form-control" placeholder="E-Mail Address" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                        <?php if($errors->has('email')): ?>
                            <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div style="margin-bottom: 0px" class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                    

                    <div class="col-md-8 col-md-offset-2">
                        <input id="password" type="password" placeholder="Password" class="form-control" name="password" required>

                        <?php if($errors->has('password')): ?>
                            <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-offset-6">

                    <a class="linkColor" href="<?php echo e(route('password.request')); ?>">
                        Forgot Your Password?
                    </a>
                </div>

                <div class="col-md-8 col-md-offset-2 buttonSurrounding">
                    <button type="submit" class="buttonFeatures">
                        Sign In
                    </button>
                </div>
                <div class="col-md-8 col-md-offset-2 buttonSurrounding">
                    <a class="linkColor" href="<?php echo e(route('register')); ?>">
                        <button type="submit" class="buttonFeatures">
                            New User?
                        </button>
                    </a>
                </div>
            </form>

        </div>
    </div>

    
    
        
            
                

                
                    
                        
                        
                            
                                
                            
                        
                        
                            

                            
                                

                                
                                    
                                        
                                    
                                
                            
                        

                        
                            

                            
                                

                                
                                    
                                        
                                    
                                
                            
                        

                        
                            
                                
                                    
                                        
                                    
                                
                            
                        

                        
                            
                                
                                    
                                

                                
                                    
                                
                            
                        
                    
                
            
        
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userLogin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>