<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Trazoo</title>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/all.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/responsive.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/filter.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/prettify.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/nprogress.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet">

</head>
<body>
    <div id="app">
        
            
                

                    
                    
                        
                        
                        
                        
                    

                    
                    
                        
                    
                

                
                    
                    
                        
                    

                    
                    
                        
                        
                            
                            
                        
                            
                                
                                    
                                

                                
                                    
                                        
                                            
                                                     
                                            
                                        

                                        
                                            
                                        
                                    
                                
                            
                        
                    
                
            
        

        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/fastclick.js')); ?>"></script>
    <script src="<?php echo e(asset('js/nprogress.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap-wysiwyg.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.hotkeys.js')); ?>"></script>
    <script src="<?php echo e(asset('js/prettify.js')); ?>"></script>

</body>
</html>
