<?php

namespace App\Http\Controllers;

use App\Business;
use Auth;
use App\User;
use Session;
use Illuminate\Http\Request;
class UserLoginController extends Controller
{
    public function login(Request $request){
        $remember = $request->get('remember');

        if(Auth::attempt([
            'number' => $request -> number,
            'password' => $request -> password,
            'role'=>'user'
        ],$remember)){
            $user = USER::where('number',$request->number)->first();

            if($user->is_blocked()){
                Auth::logout();
                Session::flush();
                return redirect() -> back()->with('message', 'Your Account has been blocked..Please Contact the admin!!');
            }
$business_user = Business::where('user_id',$user->id)->exists();
            if(!$business_user){
                return redirect('UserRegistration');
            }

            if($user->is_user()){
                return redirect()->route('home');
            }
        }
        return redirect() -> back()->with('message', 'Invalid Username or Password..!!');
    }
}
