<?php $__env->startSection('content'); ?>
    <div class="backgroundColorRegister">
        <div class="divPositionNewRegister">
            <form class="form-horizontal" method="POST" action="<?php echo e(route('register')); ?>">
                <?php echo e(csrf_field()); ?>


                <div class="form-group<?php echo e($errors->has('firstname') ? ' has-error' : ''); ?>">
                    <label for="firstname" class="col-md-offset-2 inputLabel">FirstName</label>

                    <div class="col-md-8 col-md-offset-2">
                        <input id="firstname" type="text" class="form-control" name="firstname" value="<?php echo e(old('lastname')); ?>" autofocus>

                        <?php if($errors->has('firstname')): ?>
                            <span class="help-block errorText">
                                       This field can't be blank
                                    </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group<?php echo e($errors->has('lastname') ? ' has-error' : ''); ?>">
                    <label for="lastname" class="col-md-offset-2 inputLabel">LastName</label>

                    <div class="col-md-8 col-md-offset-2">
                        <input id="lastname" type="text" class="form-control" name="lastname" value="<?php echo e(old('lastname')); ?>"  autofocus>

                        <?php if($errors->has('lastname')): ?>
                            <span class="help-block errorText">
                                        This field can't be blank
                                    </span>
                        <?php endif; ?>
                    </div>
                </div>

                
                    

                    
                        
                        

                        
                            
                                      
                                    
                        
                    
                
                
                    

                    
                        

                        
                            
                                        
                                    
                        
                    
                


                <div class="form-group<?php echo e($errors->has('number') ? ' has-error' : ''); ?> required">
                    <label for="number" class="col-md-offset-2 inputLabel">Phone Number</label>

                    <div class="col-md-8 col-md-offset-2">
                        <div class="input-group">
                            <input id="number" type="number" class="form-control" name="number" value="<?php echo e(old('number')); ?>"  autofocus
                                    >
                        <span class="input-group-btn" >
                            <button class="btn btn-secondary" type="button"  onclick="sendOTP()" style="background-color: #2350f5; color: #fff" >Send OTP</button>
                        </span>
                        </div>
                        <?php if($errors->has('number')): ?>
                            <span class="help-block errorText">
                                      <?php echo e($errors->first('number')); ?>

                                    </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group<?php echo e($errors->has('otp') ? ' has-error' : ''); ?> required">
                    <label for="otp" class="col-md-offset-2 inputLabel">OTP</label>
                    <div class="col-md-8 col-md-offset-2" style="display: inline; ">

                        <input id="otp1" name="otp1" type="text" class="inputs form-control col-xs-2"
                               style="display: inline; width: 12%; margin-right: 13px;border: solid 1px #d7d7e1"
                               maxlength="1" value="<?php echo e(old('otp1')); ?>">
                        <input id="otp2" name="otp2" type="text" class="inputs form-control col-2"
                               style="display: inline; width: 12%; margin-right: 11px;border: solid 1px #d7d7e1"
                               maxlength="1" value="<?php echo e(old('otp2')); ?>">
                        <input id="otp3" name="otp3" type="text" class="inputs form-control col-2"
                               style="display: inline; width: 12%; margin-right: 10px; border: solid 1px #d7d7e1"
                               maxlength="1" value="<?php echo e(old('otp3')); ?>">
                        <input id="otp4" name="otp4" type="text" class="inputs form-control col-2"
                               style="display: inline; width: 12%;  border: solid 1px #d7d7e1;margin-right: 10px;"
                               maxlength="1" value="<?php echo e(old('otp4')); ?>">
                        <input id="otp" name="otp" type="hidden" class="inputs form-control col-2"
                               style="display: inline; width: 12%;  border: solid 1px #d7d7e1;margin-right: 10px;"
                               maxlength="1" value="<?php echo e(old('otp')); ?>">

                        <?php if($errors->has('otp')): ?>
                            <span class="help-block errorText">
                                      <?php echo e($errors->first('otp')); ?>

                                    </span>
                        <?php endif; ?>
                    </div>
                </div>





                <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                    <label for="password" class="col-md-offset-2 inputLabel">Password</label>

                    <div class="col-md-8 col-md-offset-2">
                        <input id="password" onKeyPress="showlength()"  onKeyUp="showlength()"  type="password" class="inputWithButton" name="password" >
                        <button type="button" class="buttonAfterInput" id="showhide" style="background-color: #f6f8fd; border: solid 1px #d7d7e1"  onclick="showOrHide()">Show</button>

                        <?php if($errors->has('password')): ?>
                            <span class="help-block errorText">
                                       This field can't be blank
                                    </span>
                        <?php endif; ?>
                    </div>

                    <div class="col-md-1" id="passwordStrength" style="padding-left: 0px;padding-top: 5px">

                    </div>
                </div>

                <div class="form-group">
                    <label for="password-confirm" class="col-md-offset-2 inputLabel">Confirm Password</label>

                    <div class="col-md-8 col-md-offset-2">
                        <input id="password-confirm" type="password" class="form-control" name="password_confirmation" >

                    </div>
                </div>

                <div class="form-group">
                    <div class="col-md-2 col-md-offset-8">
                        <button type="submit" class="btn btn-primary" style="background-color:#2350f5; border: none; ">
                            Submit
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>

 function showlength(){
            var length =  document.getElementById('password').value;
            var change = document.getElementById('passwordStrength');

            if(length.length>6){
                change.innerHTML = "Good";
                change.style.color = "orange"
            }
            if(length.length<3){
                change.innerHTML = "Weak";
                change.style.color = "red"

            }
            if(length.length>8){
                change.innerHTML = "Strong";
                change.style.color = "green"

            }
        }
 function sendOTP(){
     var phone = document.getElementById('number').value;
     console.log("phone : "+phone);
     $.post('/sendOTP',{'number':phone,'_token':$('input[name=_token]').val()},function(data){
         if(data==1){
             alert("Please enter the OTP sent to your mobile.");
         }
         else if(data==0){
             alert("Account already exists with this mobile number.Please use other number.");
         }
         else{
             alert("Error Sending OTP. Please click on send OTP again..");
         }
     });

 }


        function showOrHide(){
            var change = document.getElementById('showhide');
            console.log("change.innerHTML : "+change.innerHTML);
            if(change.innerHTML == "Show"){
                change.innerHTML = "Hide";
                $("#password").prop('type','text');
            }
            else{
                change.innerHTML = "Show";
                $("#password").prop('type', 'password');
            }
        }
        
        
         $(".inputs").keyup(function () {
            if (this.value.length == this.maxLength) {
                $(this).next('.inputs').focus();
            }
        });


    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.userRegister', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>