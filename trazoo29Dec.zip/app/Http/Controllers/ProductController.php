<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
//use Illuminate\Support\Facades\Auth;
use Auth;
use App\Product;
use App\User;
use Illuminate\Auth\Events\Registered;
use Illuminate\Support\Facades\DB;


class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $product = DB::table('products')->get();
           // ->join('texts', 'pages.id', '=', 'texts.page_id')
            //->join('users', 'pages.user_id', '=', 'users.id')->where('users.id', '=', Auth::user()->id)
           // ->first();

       // return view('app.text', compact('text'));
        //$product = Product::all()->except('product_photo')->toArray();
        return view('products.index',['products' => $product]  );
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('products.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'product_name' => 'required|string|max:255',
            'product_photo' => 'required|string|max:255',
            'product_type1' => 'required|string|max:255',
            'product_type2' => 'required|string|max:255',
            'product_type3'  => 'required|string|max:255',
            'product_type4'  => 'required|string|max:255',
            'selling_format'  => 'required|string|max:255',
            'moq'  => 'required|string|max:255',
            'mrp'  => 'required|string|max:255',
            'shipping_time'  => 'required|string|max:255',
            'in_stock'  => 'required|string|max:255',
            'status'  => 'required|string|max:34',
            'warranty_duration_date'  => 'required|string|max:255',
            'warranty_duration_month'  => 'required|string|max:255',
            'warranty_provider'  => 'required|string|max:5',
            'warranty_type'  => 'required|string|max:255',
        ]);

        error_log('--------------------------------------- ');
        error_log('User to be approved is : ');
        error_log('--------------------------------------- ' );


        $product = new Product();
        $product->product_name = $request->input('product_name');
        $product->product_code = rand(1,6);
        //$product->product_photo = $request->file('product_photo')->store('public');
        $product->product_photo = $request->input('product_photo');


        $product->product_type1 = $request->input('product_type1');
        $product->product_type2 = $request->input('product_type2');
        $product->product_type3 = $request->input('product_type3');
        $product->product_type4 = $request->input('product_type4');
        $product->selling_format = $request->input('selling_format');
        $product->moq = $request->input('moq');
        $product->whole_sale_price = $request->input('whole_sale_price');
        $product->whole_sale_price = $request->input('whole_sale_price');

        $product->mrp = $request->input('mrp');

        $product->shipping_time = $request->input('shipping_time');
        $product->in_stock = $request->input('in_stock');
        $product->description = $request->input('description');
        $product->status = $request->input('status');
        $product->warranty_applicable =$request->input( 'warranty_applicable');
        $product->warranty_duration_date = $request->input('warranty_duration_date');
        $product->warranty_duration_month = $request->input('warranty_duration_month');
        $product->warranty_provider = $request->input('warranty_provider');
        $product->warranty_type = $request->input('warranty_type');
        //$product->total_variants = $request->input('total_variants');
        $product->total_variants = "22";
        $product->brand_name = $request->input('brand_name');
        $product->style_type = $request->input('style_type');
        $product->ideal_for = $request->input('ideal_for');
        $product->fabric = $request->input('fabric');
        $product->color = $request->input('color');
        $product->size = $request->input('size');
        $product->fit_type = $request->input('fit_type');
        $product->pattern_type = $request->input('pattern_type');
        $product->wash_care = $request->input('wash_care');
        $product->shipping_resp = $request->input('shipping_resp');
        $product->free_shipping = $request->input('free_shipping');
        $product->weight_per_unit = $request->input('weight_per_unit');
        $product->item_in_one_box = $request->input('item_in_one_box');
        $product->box_dimension_Length = $request->input('box_dimension_Length');
        $product->box_dimension_Breadth = $request->input('box_dimension_Breadth');
        $product->box_dimension_Height = $request->input('box_dimension_Height');
        $product->user_id = "20";

        $product->save();

        return redirect()->route('products.index');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Product $product)
    {
        //

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $product= Product::find($id);
        return view('products.edit', compact('product'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $product = Product::findorfail($id);
        $product->title = $request->get('title');
        $product->product_name = $request->get('product_name');
        //$product->product_photo = $request->file('product_photo')->store('public');
        $product->product_photo = $request->get('product_photo');


        $product->product_type1 = $request->get('product_type1');
        $product->product_type2 = $request->get('product_type2');
        $product->product_type3 = $request->get('product_type3');
        $product->product_type4 = $request->get('product_type4');
        $product->selling_format = $request->get('selling_format');
        $product->moq = $request->get('moq');
        $product->whole_sale_price = $request->get('whole_sale_price');
        $product->whole_sale_price = $request->get('whole_sale_price');

        $product->mrp = $request->get('mrp');

        $product->shipping_time = $request->get('shipping_time');
        $product->in_stock = $request->get('in_stock');
        $product->description = $request->get('description');
        $product->status = $request->get('status');
        $product->warranty_applicable =$request->get( 'warranty_applicable');
        $product->warranty_duration_date = $request->get('warranty_duration_date');
        $product->warranty_duration_month = $request->get('warranty_duration_month');
        $product->warranty_provider = $request->get('warranty_provider');
        $product->warranty_type = $request->get('warranty_type');
        //$product->total_variants = $request->input('total_variants');
        $product->total_variants = "22";
        $product->brand_name = $request->get('brand_name');
        $product->style_type = $request->get('style_type');
        $product->ideal_for = $request->get('ideal_for');
        $product->fabric = $request->get('fabric');
        $product->color = $request->get('color');
        $product->size = $request->get('size');
        $product->fit_type = $request->get('fit_type');
        $product->pattern_type = $request->get('pattern_type');
        $product->wash_care = $request->get('wash_care');
        $product->shipping_resp = $request->get('shipping_resp');
        $product->free_shipping = $request->get('free_shipping');
        $product->weight_per_unit = $request->get('weight_per_unit');
        $product->item_in_one_box = $request->get('item_in_one_box');
        $product->box_dimension_Length = $request->get('box_dimension_Length');
        $product->box_dimension_Breadth = $request->get('box_dimension_Breadth');
        $product->box_dimension_Height = $request->get('box_dimension_Height');
        $product->save();
        return redirect('/products');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        Product::destroy($id);
        return redirect()->route('products.index');
    }
}
