<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    
    <title> Trazoo </title>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('css/all.css')); ?>" rel="stylesheet">
    
    
    
    
    
    
    <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<style>
    .navbar{
        margin-bottom: 0px !important;
    }

    .navbar-default {
        background-color: white;
    }
</style>
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                       Trazoo
                    </a>
                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        &nbsp;
                    </ul>
                    <ul class="nav navbar-nav navbar-center" style="padding-top: 0px;">
                        <!-- Authentication Links -->

                        <li class="nav-item active">
                            <a class="nav-link" style="background-color: transparent;" href="#">Business Info</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" style="background-color: transparent;" href="#">Pick Up Address</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" style="background-color: transparent;" href="#">Payment Details</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" style="background-color: transparent;" href="#">Buisness &amp; KYC Info</a>
                        </li>

                    </ul>

                    <!-- Right Side Of Navbar -->
                   <!-- <ul class="nav navbar-nav navbar-right">
                        
                            <li><a href="<?php echo e(route('login')); ?>">Login</a></li>

                    </ul>-->
                </div>
            </div>
        </nav>

        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <!-- Scripts -->    <?php echo $__env->yieldContent('script'); ?>

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>

    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>

    
    
    
    
    
    

</body>
</html>
