<?php

namespace App\Http\Controllers\Auth;

use App\OTP;
use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Auth\Events\Registered;
use Ixudra\Curl\Facades\Curl;



class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
//    protected $redirectTo = '/welcome';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }


    public function register(Request $request)
    {
        $this->validator($request->all())->validate();

        event(new Registered($user = $this->create($request->all())));

       $this->guard()->login($user);

        /**return $this->registered($request, $user)
            ?: redirect('registered');*/

            return $this->registered($request, $user)
            ?: redirect('UserRegistration');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        error_log('$data[number is : '.$data['number']);



        if($data['otp1']=="" || $data['otp2']=="" || $data['otp3']=="" || $data['otp4']==""){
            $data['otp'] = "";

            $messages = [
                'otp.required' => 'Please fill all fields..',
            ];
            return Validator::make($data, [
                'firstname' => 'required|string|max:255',
                'lastname' => 'required|string|max:255',
                'number' => 'required|digits:10|max:10|unique:users',
                'otp' => 'required',
                'password' => 'required|string|min:6|confirmed',
            ],$messages);
        }

        $otp_entered = $data['otp1']."".$data['otp2']."".$data['otp3']."".$data['otp4'];
        $data['otp'] = $otp_entered;
        error_log('$otp_entered : '.$otp_entered);

        $otp_verification = OTP::where('mobile_number',$data['number'])->where('type','r')->get();
        if(count($otp_verification)>0) {
            $otp = $otp_verification[0]->otp;
            error_log('$otp is : '.$otp);
        }
        error_log('$otp_verification : '.$otp_verification);
        error_log('count($otp_verification : '.count($otp_verification));
        error_log('--------------------------------------- ');
        error_log('Number to be verified is : '.$data['number']);
        error_log('--------------------------------------- ');

        if(count($otp_verification)<1){
            $data['number'] = "";

            $messages = [
                'number.required' => 'Please send OTP to this number.',
            ];
            return Validator::make($data, [
                'firstname' => 'required|string|max:255',
                'lastname' => 'required|string|max:255',
                'number' => 'required|digits:10|max:10|unique:users',
                'otp' => 'required',
                'password' => 'required|string|min:6|confirmed',
            ],$messages);
        }

        if($otp == $data['otp']){
            return Validator::make($data, [
                'firstname' => 'required|string|max:255',
                'lastname' => 'required|string|max:255',
                'number' => 'required|digits:10|max:10|unique:users',
                'otp' => 'required',
                'password' => 'required|string|min:6|confirmed',
            ]);
        }
        else{
            $data['otp'] = "";

            $messages = [
                'otp.required' => 'Please Enter the correct OTP.',
            ];

            return Validator::make($data, [
                'firstname' => 'required|string|max:255',
                'lastname' => 'required|string|max:255',
                'number' => 'required|digits:10|max:10|unique:users',
                'otp' => 'required',
                'password' => 'required|string|min:6|confirmed',
            ],$messages);
        }
    }


    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\User
     */
    protected function create(array $data)
    {
        OTP::where('mobile_number', $data['number'])->where('type','r')->delete();

        return User::create([
            'firstname' => $data['firstname'],
            'lastname' => $data['lastname'],
            'number' => $data['number'],
            'password' => bcrypt($data['password']),
        ]);
    }


    public function sendOTPResetPassword(Request $request){

        error_log('Phone Number is : '.$request->number);

        $rules = array(
            'number' => 'required'
        );

        $validator = Validator::make(Input::all(),$rules);
        if($validator -> fails()){
            return Response::json(array('errors' => $validator->getMessageBag()->toArray()));
        }
        else{
            $user = USER::where('number',$request->number)->first();

            if(count($user)>0) {
                $phoneNumber = $request->number;
                $otp = rand(1111, 9999);

                $new_user = new OTP();
                $new_user->otp = $otp;
                $new_user->mobile_number = $phoneNumber;
                $new_user->type = "pr";
                $new_user->save();


//            Curl::to('http://tsms.my-reminders.in/api/sendmsg.php?user=trazoo&pass=trazoo@softo2018&sender=TRAZOO&phone='.$phoneNumber.'&text=Please enter this OTP '.$otp.'for creating an account on trazoo&priority=ndnd&stype=normal')
//                ->get();

      Curl::to('http://tsms.my-reminders.in/api/sendmsg.php?user=trazoo&pass=trazoo@softo2018&sender=TRAZOO&phone='.$phoneNumber.'&text='.$otp.'+Please+enter+the+otp+to+reset+password&priority=ndnd&stype=normal')
                    ->get();

                error_log('--------------------------------------- ');
                error_log('Phone Number is : '+$phoneNumber);
                error_log('$otp is : '+$otp);
                error_log('--------------------------------------- ');

                return 1;
            }

            else{
                return 0;
            }
        }
    }


}
