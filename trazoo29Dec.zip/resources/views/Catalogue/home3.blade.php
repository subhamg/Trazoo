@extends('layouts.userDashboard')

@section('content')
    <div class="col-md-10" style="background-color:transparent;margin-top:50px;">
        <nav class="navbar navbar-default "
             style="  background-color: transparent; border: none;  ">
            <div class="container">
                <div class="Home">
                    Home
                </div>



            </div>
        </nav>
        <div class="Rectangle-15" style="display: inline;">

            <div class="card-home">
                <div class="card-content-home">
                    <ul class="list-group">
                        <li class="list-group-item heading" >Inventory
                            <span class="view-all"><a href="#">View all</a></span>
                        </li>
                        <li class="list-group-item" style="margin-top: 16px">
                            Products in Stock
                            <span class="numbers">20K</span>
                        </li>
                        <li class="list-group-item" style="margin-top: 16px">
                            Products Low in Stock
                            <span class="numbers">200</span>
                        </li>
                        <li class="list-group-item" style="margin-top: 16px; border: none;">
                            Products Out of Stock
                            <span class="numbers" style="color: #ff606c;">74</span>
                        </li>
                    </ul>
                </div>

            </div>
            <div class="card-home">
                <div class="card-content-home">
                    <ul class="list-group">
                        <li class="list-group-item heading" >
                            Sales
                            <span class="view-all">View all</span>
                        </li>
                    </ul>
                    <p class="sales">₹15,40,700</p>
                    <p class="total-sales">Total Sales</p>
                    <p class="Increased-by-20"><span class="glyphicon glyphicon-upload"></span>Increased by 20%</p>
                </div>
            </div>
            <div class="card-home">
                <div class="card-content-home">
                    <ul class="list-group">
                        <li class="list-group-item heading" >
                            Orders
                            <span class="view-all">View all</span>
                        </li>
                    </ul>
                    <p class="sales">20<sup class="New">NEW</sup></p>
                    <p class="total-sales">New Orders</p>
                    <p class="total-orders">Total Orders</p>
                    <button class="button-tertiary" style="margin: 24px 0px 0px 95px; ">Add New Orders</button>
                </div>
            </div>

            <div class="card-home">
                <div class="card-content-home">
                    <ul class="list-group">
                        <li class="list-group-item heading" >
                            Catalogue
                            <span class="view-all">View all</span>
                        </li>
                    </ul>
                    <p class="sales">32</p>
                    <p class="total-sales">Product Types</p>
                    <p class="total-orders" style="width: 117px">Total 20K Products</p>
                </div>
            </div>

            <div class="card-home">
                <div class="card-content-home">
                    <ul class="list-group">
                        <li class="list-group-item heading" >
                            Connections
                            <span class="view-all">View all</span>
                        </li>
                        <li class="list-group-item " style="height:32px; line-height: .92; font-size: 12px;text-align: left;
  color: #aaaab4;" >
                            16 Messages
                            <span class="view-all"  style="line-height: .91;text-align: right;color: #2350f5;">10 New Requests</span>
                        </li>
                        <div style="overflow-y: scroll; height:200px;  margin-top: 5px;" id="style-1">
                            <li class="list-group-item " style="height:80px;"  >
                            <p class="connections">Shreen Singh</p>
                            <p class="tumblr">Tumblr &middot; Ludhiyana</p>
                            <p class="chat">Hi do you have Blue jeans in 32, 34, 36 sizes. Can be faded and should be branded...</p>
                        </li>
                        <li class="list-group-item " style="height:80px;" >
                            <p class="connections">Raman Sharma</p>
                            <p class="tumblr">Raman &middot; Sharma</p>
                            <p class="chat">Hi do you have Blue jeans in 32, 34, 36 sizes. Can be faded and should be branded...</p>

                        </li>
                            <li class="list-group-item " style="height:80px;" >
                                <p class="connections" >Rosalie Khandelwal</p>
                                <p class="tumblr" >Tumblr &middot; Ludhiyana</p>

                                <p class="chat">Hi do you have Blue jeans in 32, 34, 36 sizes. Can be faded and should be branded...</p>

                            </li>
                        </div>
                    </ul>

                </div>
            </div>

            <div class="card-home">
                <div class="card-content-home">
                    <ul class="list-group">
                        <li class="list-group-item heading" >
                            Coupons
                            <span class="view-all">View all</span>
                        </li>
                        <p class="sales">32<sup class="check">&#10003;</sup></p>
                        <p class="total-sales">Claimed Coupons</p>
                        <p class="total-orders" style="width: 117px">75 Saved Coupons</p>
                    </ul>
                </div>
            </div>

        </div>
    </div>


        @endsection