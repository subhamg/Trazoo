<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/', function () {
//    return view('auth/login');
//});



//Route::get('/admin/userList', function () {
//    return view('Admin/userList');
//})->name('admin.userList');

//Route::get('/getAllUsers',[
//    'uses' => 'AdminController@getAllUsers',
//    'as' => 'getAllUsers'
//]);

//Route::get('logout', '\App\Http\Controllers\Auth\LoginController@logout');


Route::get('/', '\App\Http\Controllers\Auth\LoginController@showLoginForm');


Route::get('/admin/login', function () {
    return view('Admin/adminLogin');
});

Route::get('/registered', function () {
    return view('postRegistration');
});

Route::get('/UserRegistration','BusinessController@myform');

Route::post('/myformPost',[
    'middleware'=>'auth',
    'as' => 'myformPost',
    'uses' => 'BusinessController@myformPost'
]);

;

//This will redirect you to user registration page.
Route::get('/UserRegistration', function(){
    return view('newUserRegistration');
});

Route::get('/getAllUsers', 'AdminController@getAllUsers')->name('getAllUsers');


Auth::routes();




Route::post('/admin',[
   'uses' => 'LoginController@login',
    'as' => 'admin.login'
]);

Route::post('approveUser',
    [
        'middleware'=>'auth',
        'as'=>'approveUser',
        'uses'=>'AdminController@approveUser'
    ]);

Route::post('resetPasswordUsingOTP',[
    'as' => 'resetPasswordUsingOTP',
    'uses' => 'Auth\ResetPasswordController@checkOTPResetPassword'
]);

Route::post('changePassword',[
    'as' => 'changePassword',
    'uses' => 'Auth\ResetPasswordController@changePassword'
]);


Route::post('blockUnbockuser',
    [
        'middleware'=>'auth',
        'as'=>'blockUnbockuser',
        'uses'=>'AdminController@blockUnbockUser'
    ]);


Route::post('sendOTP',
    [
        'as'=>'sendOTP',
        'uses'=>'AdminController@sendOTP'
    ]);

Route::post('sendOTPResetPassword',
    [
        'as'=>'sendOTPResetPassword',
        'uses'=>'Auth\RegisterController@sendOTPResetPassword'
    ]);


Route::post('/userlogin',[
    'uses' => 'UserLoginController@login',
    'as' => 'user.login'
]);

Route::group(['middleware' => 'auth'], function(){

    Route::get('/adminDashboard', function () {
        return view('adminDashBoard');
    })->name('adminDashboard');

    Route::get('/home', 'HomeController@index')->name('home');

});


// This will redirect you to the catalogue page.

Route::get('/Catalogue', function(){
    return view('Catalogue.Catalogue');
});

Route::get('/Add-Product', 'ProductController@create');

Route::post('/addProduct', 'ProductController@store')->name('addProduct');

Route::get('/products', 'ProductController@index')->name('products.index');

Route::get('/editProduct', 'ProductController@edit')->name('products.edit');

Route::post('updateProduct', 'ProductController@update')->name('products.update');

