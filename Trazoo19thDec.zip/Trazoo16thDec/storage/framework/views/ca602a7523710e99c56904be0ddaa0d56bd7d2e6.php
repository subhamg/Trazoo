<?php $__env->startSection('content'); ?>

<div class="adminDashBoard">
                Click On Users to see all users.
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminNav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>