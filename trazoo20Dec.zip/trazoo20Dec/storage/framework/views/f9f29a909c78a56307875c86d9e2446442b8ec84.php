<?php $__env->startSection('content'); ?>
    <div class="backgroundColor">
        <div class="col-md-1 titleOnTopLeft">
            Trazoo
        </div>
        <div class="divPosition">
            <div class="loginPanelHeading">
                Welcome to Trazoo
            </div>

            <div class="col-md-10 col-md-offset-1 textBelowLoginPanelHeading">
               Find buyers to connect with, add them to your network and do much more from right there.
            </div>

            <form class="form-horizontal" method="POST" action="<?php echo e(route('user.login')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="col-md-10 col-md-offset-1">
                    <?php if(session('message')): ?>
                        <div class="alert alert-warning">
                            <?php echo e(session('message')); ?>

                        </div>
                    <?php endif; ?>
                </div>

                <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                   <label for="email" class="col-md-offset-2 inputLabel">Email ID</label>


                    <div class="col-md-8 col-md-offset-2">
                        <input id="email" type="email" class="form-control" placeholder="E-Mail Address" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                        <?php if($errors->has('email')): ?>
                            <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                    <div class="col-md-10 forgotPassoword">    <label for="password" class="col-md-offset-2 inputLabel">Password</label>
                        <a class="linkColor" href="<?php echo e(route('password.request')); ?>">
                            Forgot Your Password?
                        </a>
                </div>
                    <div class="col-md-8 col-md-offset-2">
                        <input id="password" type="password" placeholder="Password" class="form-control" name="password" required>

                        <?php if($errors->has('password')): ?>
                            <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                        <?php endif; ?>
                    </div>
                </div>

                    <div class="col-md-6 col-md-offset-2 aligntoLeft">
                        <div class="checkbox">
                            <input class="" type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                            <label class="aligntoLeft">
                               Remember Me
                            </label>
                        </div>
                    </div>



                <div class="col-md-8 col-md-offset-2 buttonSurrounding">
                    <button type="submit" class="buttonFeatures">
                        Sign In
                    </button>
                </div>

                <div class="col-md-2 col-md-offset-5" style="text-align: center">
                    OR
                </div>

                <div class="col-md-8 col-md-offset-2 buttonSurrounding">
                    <a class="linkColor" href="<?php echo e(route('register')); ?>">
                        <button type="submit" class="buttonFeaturesRegister">
                            Create new User?
                        </button>
                    </a>
                </div>
            </form>

        </div>
    </div>

    
    
        
            
                

                
                    
                        
                        
                            
                                
                            
                        
                        
                            

                            
                                

                                
                                    
                                        
                                    
                                
                            
                        

                        
                            

                            
                                

                                
                                    
                                        
                                    
                                
                            
                        

                        
                            
                                
                                    
                                        
                                    
                                
                            
                        

                        
                            
                                
                                    
                                

                                
                                    
                                
                            
                        
                    
                
            
        
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userLogin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>