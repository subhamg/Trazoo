@extends('layouts.userDashboard')

@section('content')
    <div class="col-md-10" style="background-color:transparent;margin-top:50px;">
        <nav class="navbar navbar-default "
             style="  background-color: transparent; border: none;  ">
            <div class="container">
                <div class="Home">
                    Home
                </div>



            </div>
        </nav>
        <div class="Rectangle-15" style="display: inline;">

                <div class="card-home">
                    <div class="card-content-home">
                        <ul class="list-group">
                            <li class="list-group-item heading" >Inventory
                                <span class="view-all">View all</span>
                            </li>
                            <li class="list-group-item" style="margin-top: 16px">
                                Products in Stock
                                <span class="numbers">100</span>
                            </li>
                            <li class="list-group-item" style="margin-top: 16px">
                                Products Low in Stock
                                <span class="numbers">0</span>
                            </li>
                            <li class="list-group-item" style="margin-top: 16px; border: none;">
                                Products Out of Stock
                                <span class="numbers">0</span>
                            </li>
                        </ul>
                    </div>

                </div>
            <div class="card-home">
                <div class="card-content-home">
                    <ul class="list-group">
                        <li class="list-group-item heading" >
                            Sales
                            <span class="view-all">View all</span>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="card-home">
                <div class="card-content-home">
                    <ul class="list-group">
                        <li class="list-group-item heading" >
                            Orders
                            <span class="view-all">View all</span>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="card-home">
                <div class="card-content-home">
                    <ul class="list-group">
                        <li class="list-group-item heading" >
                            Catalogue
                            <span class="view-all">View all</span>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="card-home">
                <div class="card-content-home">
                    <ul class="list-group">
                        <li class="list-group-item heading" >
                            Connections
                            <span class="view-all">View all</span>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="card-home">
                <div class="card-content-home">
                    <ul class="list-group">
                        <li class="list-group-item heading" >
                            Coupons
                            <span class="view-all">View all</span>
                        </li>
                    </ul>
                </div>
            </div>

        </div>
    </div>





@endsection