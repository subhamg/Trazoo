<?php $__env->startSection('content'); ?>

            <div class="right_col" role="main">
                <div class="">

                    <div class="clearfix"></div>
                    
                        
                            
                                
                            
                        
                        

                    <div class="x_content">


                        <ul class="tab-top-head">
                            <li><a href="#">Buyers</a></li>
                            <li id="sellersList" class="active"  onclick="showSellers()"><a href="#">Sellers</a></li>
                            <li id="pendingSellersList" onclick="showPendingSellers()"><a href="#">Pending Sellers</a></li>
                            <li><a href="#">Blocked Users</a></li>
                        </ul>
                        <div class="table-responsive">
                            <table class="table  jambo_table bulk_action tab-bold-head">
                                <thead>
                                <tr class="headings">
                                    <th class="column-title"></th>
                                    <th class="column-title">Status</th>
                                    <th class="column-title">Block</th>
                                    <th class="column-title">User ID</th>
                                    <th class="column-title">DOJ</th>
                                    <th class="column-title">Name</th>
                                    <th class="column-title"  style="text-align: center">Email ID</th>
                                    <th class="column-title">Business type</th>
                                    <th class="column-title">Product Category</th>
                                    <th class="column-title">Product Uploads</th>
                                    <th class="column-title">PickUp Address</th>
                                    <th class="column-title">Location</th>
                                    <th class="column-title">State</th>
                                    <th class="column-title">Total Orders</th>
                                    <th class="column-title">Gross Business</th>
                                    <th class="column-title">Last Active</th>



                                </tr>
                                </thead>
                                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tbody>



                                <tr class="even" id="approvedSellers">
                                    <td class=" ">
                                        <div id="userId_<?php echo e($u->id); ?>">
                                        <label class="checkbox-wp  checktick">
                                            <input type="checkbox">
                                            <span class="checkmark"></span>
                                        </label>
                                    </div>
                                    </td>

                                    <td class=" ">
                                        <div class="hidden-div" id="hidden-div_<?php echo e($u->id); ?>">Approved</div>
                                        <?php if($u->isApproved != 1): ?>
                                            <div  id="userId_<?php echo e($u->id); ?>" >
                                                <button onclick="approveUser(<?php echo e($u->id); ?>)">
                                                    Approve
                                                </button>
                                            </div>
                                            <?php else: ?>
                                            Approved
                                        <?php endif; ?>
                                    </td>

                                    <td class=" ">

                                            <div>
                                                <button  class="blockId_<?php echo e($u->id); ?>"  id="blockId_<?php echo e($u->id); ?>"  onclick="blockOrUnblockUser(<?php echo e($u->id); ?>)">
                                                    <?php if($u->isBlocked == 1): ?>
                                                    Unblock
                                                        <?php else: ?>
                                                        Block
                                                    <?php endif; ?>
                                                </button>
                                            </div>
                                    </td>

                                    <td class=" "><?php echo e($u->id); ?></td>
                                    <td class=" "><?php echo e($u->created_at); ?></td>
                                    <td class=" "><?php echo e($u->firstname); ?> <?php echo e($u->lastname); ?></td>
                                    <td class=" "><?php echo e($u->email); ?></td>
                                    <td class=" "><?php echo e($u->number); ?></td>
                                    <td class=" "><?php echo e($u->businesstype); ?></td>
                                    <td class=" ">Product</td>
                                    <td class=" ">uploads</td>
                                    <td class=" "><?php echo e($u->addressline1); ?>,<?php echo e($u->addressline2); ?>,
                                        <?php echo e($u->landmark); ?></td>
                                    <td class=" "><?php echo e($u->city); ?></td>
                                    <td class=" "><?php echo e($u->state); ?></td>
                                    <td class=" ">orders</td>
                                    <td class=" ">Business</td>
                                    <td class=" ">today</td>



                                </tr>

                                <?php if($u->isApproved != 1): ?>


                                    <tr class="even" id = "pendingSellers" onclick="selectPendingSeller(<?php echo e($u->id); ?>)">
                                        <div  ></div>
                                        <td class=" ">
                                            <div id="userId_<?php echo e($u->id); ?>">
                                                <label class="checkbox-wp  checktick">
                                                    <input id="pendingSeller_<?php echo e($u->id); ?>" type="checkbox">
                                                    <span class="checkmark"></span>
                                                </label>
                                            </div>
                                        </td>

                                        <td class=" ">
                                            <div class="hidden-div" id="hidden-div_<?php echo e($u->id); ?>">Approved</div>
                                            <?php if($u->isApproved != 1): ?>
                                                <div  id="userId_<?php echo e($u->id); ?>" >
                                                    <button onclick="approveUser(<?php echo e($u->id); ?>)">
                                                        Approve
                                                    </button>
                                                </div>
                                            <?php else: ?>
                                                Approved
                                            <?php endif; ?>
                                        </td>

                                        <td class=" ">

                                            <div>
                                                <button  class="blockId_<?php echo e($u->id); ?>"  id="blockId_<?php echo e($u->id); ?>"  onclick="blockOrUnblockUser(<?php echo e($u->id); ?>)">
                                                    <?php if($u->isBlocked == 1): ?>
                                                        Unblock
                                                    <?php else: ?>
                                                        Block
                                                    <?php endif; ?>
                                                </button>
                                            </div>
                                        </td>

                                        <td class=" "><?php echo e($u->id); ?></td>
                                        <td class=" "><?php echo e($u->created_at); ?></td>
                                        <td class=" "><?php echo e($u->firstname); ?> <?php echo e($u->lastname); ?></td>
                                        <td class=" "><?php echo e($u->email); ?></td>
                                        <td class=" "><?php echo e($u->number); ?></td>
                                        <td class=" "><?php echo e($u->businesstype); ?></td>
                                        <td class=" ">Product</td>
                                        <td class=" ">uploads</td>
                                        <td class=" "><?php echo e($u->addressline1); ?>,<?php echo e($u->addressline2); ?>,
                                            <?php echo e($u->landmark); ?></td>
                                        <td class=" "><?php echo e($u->city); ?></td>
                                        <td class=" "><?php echo e($u->state); ?></td>
                                        <td class=" ">orders</td>
                                        <td class=" ">Business</td>
                                        <td class=" ">today</td>



                                    </tr>



                                <?php endif; ?>

                                </tbody>



                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>



                    </div>
                </div>
            </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>


    <script>

        window.onload = function() {
            $('#pendingSellers').hide();

//            $('#approvedSellers').hide();
        };



        var user_id = [];

        function selectPendingSeller(id){
            if($("#pendingSeller_"+id).prop('checked') == true){
                //do something
                $('#pendingSeller_'+id).prop('checked', false);

            }else{
            $('#pendingSeller_'+id).prop('checked', true);
            }
        }


        function showPendingSellers(){
            $('#pendingSellers').show();
            $('#approvedSellers').hide();
            $('#pendingSellersList').addClass('active')
            $('#sellersList').removeClass('active')
        }

        function showSellers(){
            $('#pendingSellers').hide();
            $('#approvedSellers').show();
            $('#pendingSellersList').removeClass('active')
            $('#sellersList').addClass('active')
        }


        function approveUser(id){
            console.log("User id to approve is : "+id);

            $.post('/approveUser',{'id':id,'_token':$('input[name=_token]').val()},function(data){
                if(data==1){
                    console.log('Successfull');
                    $('#userId_'+id).hide();
                    $("#hidden-div_"+id).show();
                    alert("User Approved..!!");
                }
                else{
                    alert("Error approving user.");
                }
            });
        }

// this.user_id = [];

        function blockOrUnblockUser(id){
            console.log("User id to be blocked or unblocked is : "+id);
            var change = document.getElementById('blockId_'+id);
            console.log("change.innerHTML : "+change.innerHTML);

            $.post('/blockUnbockuser',{'id': id,'_token':$('input[name=_token]').val()},function(data){
                if(data==1){
                    if(change.innerHTML.trim() == "Block"){
                        change.innerHTML = "Unblock";
                    }
                    else{
                        change.innerHTML = "Block";
                    }
                    alert("User UnBlocked..!!");
                }
                else{
                    alert("Error Performing this function user.");
                }
            });
        }
    </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminNav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>