@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Reset Password</div>

                <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                    <form class="form-horizontal" method="POST" action="{{ route('password.email') }}">
                        <input type="hidden" name="_token" value="{{ csrf_token() }}">

                        <div id="phoneNumber" class="form-group{{ $errors->has('number') ? ' has-error' : '' }}">
                            <label for="email" class="col-md-4 control-label">Phone Number</label>

                            <div class="col-md-6">
                                <input id="number" type="number" class="form-control" name="number" value="{{ old('number') }}" >
                                <div id="numberLengthError" style="font-size: small;color: red"></div>
                                @if ($errors->has('number'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('number') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div id="afterSendingOTP" style="display: none">
                        <div class="form-group{{ $errors->has('otp') ? ' has-error' : '' }}">
                            <label for="email" class="col-md-4 control-label">OTP</label>

                            <div class="col-md-6">
                                <input id="otp" type="number" maxlength="4"  class="form-control" name="otp" value="{{ old('otp') }}" >
                                <div id="otpError" style="font-size: small;color: red"></div>
                                @if ($errors->has('otp'))

                                    <span class="help-block">
                                        <strong>{{ $errors->first('otp') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group" id="">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="button"  onclick="sendEnteredOTP()" class="btn btn-primary">
                                    Submit
                                </button>
                            </div>
                        </div>
                </div>

                        <div id="afterConfirmingOTP" style="display: none">
                            <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                                <label for="password" class="col-md-4 control-label">Password</label>

                                <div class="col-md-6">
                                    <input id="password" type="password" class="form-control" name="password" required>
                                    <div id="passwordError" style="font-size: small;color: red"></div>

                                    @if ($errors->has('password'))
                                        <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group{{ $errors->has('password_confirmation') ? ' has-error' : '' }}">
                                <label for="password-confirm" class="col-md-4 control-label">Confirm Password</label>
                                <div class="col-md-6">
                                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                                    <div id="password-confirmError" style="font-size: small;color: red"></div>

                                    @if ($errors->has('password_confirmation'))
                                        <span class="help-block">
                                        <strong>{{ $errors->first('password_confirmation') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group" id="">
                                <div class="col-md-6 col-md-offset-4">
                                    <button type="button"  onclick="changePassword()" class="btn btn-primary">
                                        Change Password
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div id="afterPasswordChanged" style="display: none">
                         Password Changed Successfully.Go back to Login Page.
                        </div>



                        <div class="form-group" id="sendOTPButton">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="button" class="btn btn-primary"  onclick="sendOTP()" >
                                    Send OTP
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('script')
    <script>

var phone;
var otpSent;
var otpConfirmed;
        function sendOTP(){
            var phone = document.getElementById('number').value;
            this.phone = phone;
            console.log("this.phone : "+this.phone);

            var phoneLength = document.getElementById('numberLengthError');
            phoneLength.innerHTML = "";
            console.log("phone : "+phone);
            if(phone.length!=10){
                phoneLength.innerHTML = "Phone number must be of atleast 10 digits.";
                phoneLength.style.color = "red"
            }
            else{
                $.post('/sendOTPResetPassword',{'number':phone,'_token':$('input[name=_token]').val()},function(data){
                    if(data==1){
                        alert("Please enter the OTP sent to your mobile.");
                        $('#sendOTPButton').remove();
                        $('#afterSendingOTP').show();
                        this.otpSent = true;
                    }
                    else if(data==0){
                        alert("Account already exists with this mobile number.Please use other number.");
                    }
                    else{
                        alert("Error Sending OTP. Please click on send OTP again..");
                    }
                });
            }

        }



        function sendEnteredOTP(){
            var otp = document.getElementById('otp').value;
            var otpLength = document.getElementById('otpError');
            otpLength.innerHTML = "";
            console.log("phone : "+otpLength);
            if(otp.length<4){
                otpLength.innerHTML = "OTP should be of 4 digits.";
                otpLength.style.color = "red"
            }
            else{
                $.post('/resetPasswordUsingOTP',{'number':this.phone,'otp':otp,'_token':$('input[name=_token]').val()},function(data){
                    if(data==1){
                        $('#afterSendingOTP').remove();
                        $('#afterConfirmingOTP').show();
                        this.otpConfirmed = true;
                    }
                    else{
                        alert("Error Sending OTP. Please click on send OTP again..");
                    }
                });
            }

        }

function changePassword(){
    var password_confirm = document.getElementById('password-confirm').value;
    var password = document.getElementById('password').value;
    var password_Error = document.getElementById('passwordError');
    var password_confirmError = document.getElementById('password-confirmError');
    password_Error.innerHTML = ""
    password_confirmError.innerHTML = ""
    password = password.trim();
    password_confirm = password_confirm.trim();

    if(password.length<6){
        password_Error.innerHTML = "Password should be of 6 characters.";
        password_Error.style.color = "red"
    }
    else{
        if(password_confirm == password){
        $.post('/changePassword',{'number':this.phone,'password':password,'_token':$('input[name=_token]').val()},function(data){
            if(data==1){
                $('#afterConfirmingOTP').remove();
                $('#phoneNumber').remove();

                $('#afterPasswordChanged').show();
//                this.otpConfirmed = true;
                alert("Password Changed..");
            }
            else{
                alert("Password not Changed..");
            }
        });
        }
        else{
            password_Error.innerHTML = "Passwords Do not match.";
            password_Error.style.color = "red"
            password_confirmError.innerHTML = "Passwords Do not match.";
            password_confirmError.style.color = "red"

        }
    }

}

    </script>

@endsection
