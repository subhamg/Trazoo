<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Trazoo</title>

    <!-- Styles -->
    {{--<link href="{{ asset('css/app.css') }}" rel="stylesheet">--}}
    {{--<link href="{{ asset('css/all.css') }}" rel="stylesheet">--}}

    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link href="{{ asset('css/all.css') }}" rel="stylesheet">
    {{--<link href="{{ asset('css/responsive.css') }}" rel="stylesheet">--}}
    {{--<link href="{{ asset('css/custom.css') }}" rel="stylesheet">--}}
    {{--<link href="{{ asset('css/filter.css') }}" rel="stylesheet">--}}
    {{--<link href="{{ asset('css/prettify.min.css') }}" rel="stylesheet">--}}
    {{--<link href="{{ asset('css/nprogress.css') }}" rel="stylesheet">--}}
    {{--<link href="{{ asset('css/font-awesome.min.css') }}" rel="stylesheet">--}}
    <link href="{{ asset('css/bootstrap.css') }}" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">

    <style>

        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        body{
            background-color: #f6f8fd;
        }

        .navbar {
            background-color: #ffffff;
            box-shadow: 0 0 3px 0 rgba(10, 10, 20, 0.13);

        }

        .navbar-default .navbar-brand{
            font-family: 'Open Sans';
            font-size: 16px;
            font-weight: 600;
            font-style: normal;
            font-stretch: normal;
            line-height: normal;
            letter-spacing: 0.5px;
            text-align: center;
            color: #2350f5;
        }
        .forget-password {
            width: 500px;
            height: 309px;
            border-radius: 10px;
            background-color: #ffffff;
            border: solid 1px #e9edf8;
        }

        .Forgot-your-password{

            font-family: 'Open Sans';
            font-size: 28px;
            font-weight: 300;
            font-style: normal;
            font-stretch: normal;
            line-height: 1.32;
            letter-spacing: normal;
            text-align: center;
            color: #0a0a14;
            padding-top: 40px;
        }

        .No-worries-Lets-fin{
            font-family: 'Open Sans';
            font-size: 13px;
            font-weight: normal;
            font-style: normal;
            font-stretch: normal;
            line-height: 1.77;
            letter-spacing: normal;
            text-align: center;
            color: #0a0a14;
            padding-top: 4px;
            padding-left: 65px;
            padding-right: 65px;
        }

        .Enter-your-registere{
            font-family: 'Open Sans';
            font-size: 12px;
            font-weight: 600;
            font-style: normal;
            font-stretch: normal;
            line-height: 1;
            letter-spacing: normal;
            text-align: left;
            color: #0a0a14;
            padding-top: 50px;
            margin-left:5px;
            margin-bottom: 5px;
            margin-top: 15px;

        }

        .input_rectangle {
            width: 500px;
            height: 40px;
            border-radius: 5px;

            padding-left: 100px;
            padding-right: 100px;
            padding-top: 8px;
            margin-top: 15px;
            float: none;

        }
        .input_rectangle input{
            border: solid 1px #d7d7e1;
        }

        .input_rectangle input:hover{
            border: solid 1px #2350f5;
        }

        .input_rectangle input:focus{
            border: solid 1px #2350f5;
        }
        .button-primary {

            min-width: 88px;
            height: 32px;
            border-radius: 4px;
            background-color: #1c62fd;
            border: none;
            font-family: OpenSans;
            font-size: 13px;
            font-weight: 600;
            font-style: normal;
            font-stretch: normal;
            line-height: 1;
            letter-spacing: normal;
            text-align: center;
            color: #ffffff;
            padding: 0 16px;
            margin: 0 6px;
            margin-top: 24px;

        }

        .button-primary:hover {

            background-color: #1e42c8;

        }

        .button-primary:active {

            background-color: #19349b;

        }

        .button-primary:focus {

            outline: 0;

        }


        .button-primary:disabled {

            background-color:  #bdcbfc;

        }

.full-circle{
            background-color: rgba(216, 255, 212, 0.23);
            border: solid 1px #4eba41;
            height:80px;
            width:80px;
            -webkit-border-radius:40px;
            -moz-border-radius:40px;
            margin:40px 210px;
            color: #56be4b;
            padding-top:20px;
            font-size: 30px;
            
        }

    </style>
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
                    <a class="navbar-brand" href="{{ url('/') }}">
                        {{ config('app.name', 'Laravel') }}
                    </a>
                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        &nbsp;
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        @if (Auth::guest())
                            <li><a href="{{ route('login') }}">Login</a></li>
                            <li><a href="{{ route('register') }}">Register</a></li>
                        @else
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    {{ Auth::user()->name }} <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <a href="{{ route('logout') }}"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                            {{ csrf_field() }}
                                        </form>
                                    </li>
                                </ul>
                            </li>
                        @endif
                    </ul>
                </div>
            </div>
        </nav>

        @yield('content')
    </div>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}"></script>
    @yield('script')

    {{--<script src="{{ asset('js/jquery.min.js') }}"  type="text/javascript"></script>--}}
    {{--<script src="{{ asset('js/bootstrap.min.js') }}"></script>--}}
    {{--<script src="{{ asset('js/fastclick.js') }}"></script>--}}
    {{--<script src="{{ asset('js/nprogress.js') }}"></script>--}}
    {{--<script src="{{ asset('js/bootstrap-wysiwyg.min.js') }}"></script>--}}
    {{--<script src="{{ asset('js/jquery.hotkeys.js') }}"></script>--}}
    {{--<script src="{{ asset('js/prettify.js') }}"></script>--}}
</body>
</html>
