<?php

namespace App\Http\Controllers;

use Auth;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class LoginController extends Controller
{
    public function login(Request $request){
        $remember = $request->get('remember');

        if(Auth::attempt([
            'number' => $request -> number,
            'password' => $request -> password,
            'role'=>'admin'
        ], $remember)){
            $user = USER::where('number',$request->number)->first();
            if($user->is_admin()){
                return redirect()->route('adminDashboard');
            }
//            Auth::logout();
//            return redirect('/login');
        }
        return redirect() -> back()->with('message', 'Invalid Phone Number or Password..!!');;
    }

public function logout(){
    Auth::logout();
    Session::flush();
    return redirect::route("/admin/login");
}
}
