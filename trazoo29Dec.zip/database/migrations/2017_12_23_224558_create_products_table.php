<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        Schema::enableForeignKeyConstraints();

        Schema::create('products', function (Blueprint $table) {

            $table->increments('id');
            $table->string('product_name');
            $table->string('product_code');
            $table->string('product_photo');
            $table->string('product_type1');
            $table->string('product_type2');
            $table->string('product_type3');
            $table->string('product_type4');
            $table->string('selling_format');
            $table->string('moq');
            $table->string('whole_sale_price');
            $table->string('mrp');
            $table->string('shipping_time');
            $table->string('in_stock');
            $table->longText('description',500);
            $table->string('status');
            $table->string('warranty_applicable');
            $table->string('warranty_duration_date');
            $table->string('warranty_duration_month');
            $table->string('warranty_provider');
            $table->string('warranty_type');
            $table->string('total_variants');
            $table->string('brand_name');
            $table->string('style_type');
            $table->string('ideal_for');
            $table->string('fabric');
            $table->string('color');
            $table->string('size');
            $table->string('fit_type');
            $table->string('pattern_type');
            $table->string('wash_care');
            $table->string('shipping_resp');
            $table->string('free_shipping');
            $table->string('weight_per_unit');
            $table->string('item_in_one_box');
            $table->string('box_dimension_Length');
            $table->string('box_dimension_Breadth');
            $table->string('box_dimension_Height');
            $table->integer('user_id')->unsigned();
            $table->foreign('user_id')->references('id')->on('users');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
        schema::dropIfExists('products');
    }
}
