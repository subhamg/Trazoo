<?php $__env->startSection('content'); ?>

            <div class="right_col" role="main">
                <div class="">

                    <div class="clearfix"></div>


                    <div class="x_content">


                        <ul class="tab-top-head">
                            <li class="active"><a href="#">Buyers</a></li>
                            <li><a href="#">Sellers</a></li>
                            <li><a href="#">Pending Sellers</a></li>
                            <li><a href="#">Blocked Users</a></li>
                        </ul>
                        <div class="table-responsive">
                            <table class="table  jambo_table bulk_action tab-bold-head">
                                <thead>
                                <tr class="headings">
                                    <th class="column-title"></th>
                                    <th class="column-title">Status</th>
                                    <th class="column-title">Block</th>
                                    <th class="column-title">First Name</th>
                                    <th class="column-title">Last Name</th>
                                    <th class="column-title">Phone</th>
                                    <th class="column-title">Mail ID</th>

                                </tr>
                                </thead>

                                <tbody>

                                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr class="even">
                                    <td class=" ">
                                        <label class="checkbox-wp  checktick">
                                            <input type="checkbox">
                                            <span class="checkmark"></span>
                                        </label>
                                    </td>

                                    <td class=" ">
                                        <div class="hidden-div" id="hidden-div_<?php echo e($u->id); ?>">Approved</div>
                                        <?php if($u->isApproved != 1): ?>
                                            <div  id="userId_<?php echo e($u->id); ?>" >
                                                <button onclick="approveUser(<?php echo e($u->id); ?>)">
                                                    Approve
                                                </button>
                                            </div>
                                            <?php else: ?>
                                            Approved
                                        <?php endif; ?>
                                    </td>

                                    <td class=" ">

                                            <div>
                                                <button  class="blockId_<?php echo e($u->id); ?>"  id="blockId_<?php echo e($u->id); ?>"  onclick="blockOrUnblockUser(<?php echo e($u->id); ?>)">
                                                    <?php if($u->isBlocked == 1): ?>
                                                    Unblock
                                                        <?php else: ?>
                                                        Block
                                                    <?php endif; ?>
                                                </button>
                                            </div>
                                    </td>

                                    <td class=" "><?php echo e($u->firstname); ?></td>
                                    <td class=" "><?php echo e($u->lastname); ?></td>
                                    <td class=" "><?php echo e($u->number); ?></td>
                                    <td class=" "><?php echo e($u->email); ?></td>


                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>



                    </div>
                </div>
            </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>


    <script>


        function approveUser(id){
            console.log("User id to approve is : "+id);

            $.post('/approveUser',{'id':id,'_token':$('input[name=_token]').val()},function(data){
                if(data==1){
                    console.log('Successfull');
                    $('#userId_'+id).hide();
                    $("#hidden-div_"+id).show();
                    alert("User Approved..!!");
                }
                else{
                    alert("Error approving user.");
                }
            });
        }

        function blockOrUnblockUser(id){
            console.log("User id to be blocked or unblocked is : "+id);
            var change = document.getElementById('blockId_'+id);
            console.log("change.innerHTML : "+change.innerHTML);

            $.post('/blockUnbockuser',{'id': id,'_token':$('input[name=_token]').val()},function(data){
                if(data==1){
                    if(change.innerHTML.trim() == "Block"){
                        change.innerHTML = "Unblock";
                    }
                    else{
                        change.innerHTML = "Block";
                    }
                    alert("User UnBlocked..!!");
                }
                else{
                    alert("Error Performing this function user.");
                }
            });
        }
    </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminNav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>